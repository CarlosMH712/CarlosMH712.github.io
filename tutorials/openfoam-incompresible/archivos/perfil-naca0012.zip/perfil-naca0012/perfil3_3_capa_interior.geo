// Perfil NACA con el campo lejano a 500 cuerdas · paso 3: la capa interior
// Es el dominio en C del 2.2.2 en pequeño, a una distancia H1 del perfil (medio cuerda): la
// misma numeración, las radiales de las estaciones verticales y la estela con su propia
// salida. Ahí las líneas de la malla salen casi perpendiculares a la pared, y de eso depende
// la fricción.
Include "perfil3_2_perfil.geo";

// La capa termina en el nodo K de la progresión radial: H1 es la altura de ese nodo (la más
// cercana a hPiso), así que la progresión sigue sin salto en el abanico del paso 4.
h0 = R * (rRadial - 1) / (rRadial^(nRadial - 1) - 1);   // primera celda que reparte Gmsh
K = Floor(Log(1 + hPiso * (rRadial - 1) / h0) / Log(rRadial) + 0.5);
H1 = h0 * (rRadial^K - 1) / (rRadial - 1);
hJ = h0 * rRadial^(K - 1);                              // última celda de la capa

// En la salida, la capa no puede llevar las celdas de la pared: 500 cuerdas atrás, una fila de
// 1e-5 c no tiene sentido. Sube de hSalida a hJ en las mismas K celdas, y por eso termina a
// otra altura, H2.
rPiso = (hJ / hSalida)^(1 / (K - 1));
H2 = hSalida * (rPiso^K - 1) / (rPiso - 1);

cBS = 1000 + n;                               // el borde de salida
xo = c + L;                                   // salida
xc = xs * c;                                  // centro de la media elipse

Point(1) = {-H1, 0, 0};                                         // frente
Point(2) = {xc, 0, 0};                                          // centro de la elipse
pS[]  = Point{1000 + ks};   pI[]  = Point{2000 + ks};           // las estaciones del perfil
pR1s[] = Point{1000 + kr1}; pR1i[] = Point{2000 + kr1};
pR2s[] = Point{1000 + kr2}; pR2i[] = Point{2000 + kr2};
Point(3)  = {pS[0],   pS[1] + H1, 0};    Point(4)  = {pI[0],   pI[1] - H1, 0};
Point(5)  = {pR1s[0], pR1s[1] + H1, 0};  Point(6)  = {pR1i[0], pR1i[1] - H1, 0};
Point(7)  = {pR2s[0], pR2s[1] + H1, 0};  Point(8)  = {pR2i[0], pR2i[1] - H1, 0};
Point(9)  = {c, H1, 0};                  Point(10) = {c, -H1, 0};
Point(11) = {xo, H2, 0};                 Point(12) = {xo, -H2, 0};
Point(13) = {xo, 0, 0};                                         // fin del corte de estela

// La media elipse pasa por el frente y por los puntos 3 y 4; el tercer punto sólo fija la
// dirección del primer semieje (2.2.2).
Ellipse(11) = {1, 2, 1, 3};   Ellipse(12) = {1, 2, 1, 4};
Line(13) = {3, 5};  Line(14) = {5, 7};  Line(15) = {7, 9};  Line(16) = {9, 11};
Line(17) = {4, 6};  Line(18) = {6, 8};  Line(19) = {8, 10}; Line(20) = {10, 12};
Line(21) = {cBS, 13};                                           // corte de estela, en la cuerda

Line(22) = {1000, 1};                                           // las radiales de la capa
Line(23) = {1000 + ks,  3};  Line(24) = {1000 + kr1, 5};
Line(25) = {1000 + kr2, 7};  Line(26) = {cBS,        9};
Line(27) = {2000 + ks,  4};  Line(28) = {2000 + kr1, 6};
Line(29) = {2000 + kr2, 8};  Line(30) = {cBS,       10};
Line(31) = {13, 11};  Line(32) = {13, 12};                      // la salida de la capa

Printf("capa interior: %g celdas, %g c junto al perfil y %g c en la salida (progresión %g)",
       K, H1, H2, rPiso);
