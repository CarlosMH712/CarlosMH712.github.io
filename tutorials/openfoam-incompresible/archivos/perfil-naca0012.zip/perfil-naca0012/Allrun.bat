@echo off
rem Perfil NACA 0012, Re = 6e6, Spalart-Allmaras, en blueCFD-Core 2024 (OpenFOAM 12).
rem Uso, desde la terminal cmd de blueCFD y en la carpeta del caso:  Allrun.bat
rem Hace lo mismo que la receta de la guia: malla con Gmsh, gmshToFoam, tipos de los parches del perfil y de
rem las caras planas, checkMesh y foamRun, en serie. Gmsh tiene que estar en el PATH.
setlocal
cd /d %~dp0

where gmsh > nul 2>&1 || (echo No se encuentra gmsh: agregue su carpeta al PATH, por ejemplo& echo     set PATH=%%PATH%%;C:\gmsh-4.15.2-Windows64& exit /b 1)
call gmsh perfil3_7_openfoam.geo -3 -o perfil.msh -log log.gmsh > nul 2>&1 || goto fallo
gmshToFoam perfil.msh > log.gmshToFoam 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/airfoil/type -set wall > log.foamDictionary 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/frontAndBack/type -set empty >> log.foamDictionary 2>&1 || goto fallo
checkMesh > log.checkMesh 2>&1 || goto fallo
foamRun > log.foamRun 2>&1 || goto fallo
echo Listo. Coeficientes en postProcessing\fuerzas\0, presion y friccion en la pared en postProcessing\pared.
goto :eof

:fallo
echo Fallo un paso: revisa el ultimo log.* de la carpeta del caso.
exit /b 1
