// Perfil NACA con el campo lejano a 500 cuerdas · paso 2: el contorno del perfil
// El del 2.2.2, con una opción más: la definición del NACA 0012 que usa la NASA en su caso de
// validación.
Include "perfil3_1_parametros.geo";

// Numeración: 1000 + i el extradós, 2000 + i el intradós. El borde de ataque (1000) y el de
// salida (1000 + n) son de las dos caras.
sTramo[] = {0, 0, 0, 0};       // longitud de arco de los cuatro tramos del extradós
xAnt = 0;  yAnt = 0;

For i In {0:n}
  x = 0.5 * (1.0 - Cos(Pi * i / n));                  // espaciado coseno
  If (nasa)
    // NASA: la fórmula exacta (−0.1015 x⁴) se prolonga hasta x = 1.00893, donde el espesor
    // se anula, y se reescala a cuerda 1; el borde de salida queda agudo y el espesor en
    // 11.894 %.
    yt = t / 0.12 * 0.594689181 * (0.298222773 * Sqrt(x) - 0.127125232 * x - 0.357907906 * x^2
                                   + 0.291984971 * x^3 - 0.105174606 * x^4);
  Else
    yt = 5.0 * t * (0.2969 * Sqrt(x) - 0.1260 * x - 0.3516 * x^2
                    + 0.2843 * x^3 - 0.1036 * x^4);    // borde de salida cerrado (2.2.2)
  EndIf

  yc = 0.0;  dyc = 0.0;                                // línea de curvatura
  If (m > 0)
    If (x < p)
      yc = m / p^2 * (2.0 * p * x - x^2);
      dyc = 2.0 * m / p^2 * (p - x);
    Else
      yc = m / (1.0 - p)^2 * ((1.0 - 2.0 * p) + 2.0 * p * x - x^2);
      dyc = 2.0 * m / (1.0 - p)^2 * (p - x);
    EndIf
  EndIf
  th = Atan(dyc);

  // El espesor se mide perpendicular a la línea de curvatura.
  xu = c * (x - yt * Sin(th));   yu = c * (yc + yt * Cos(th));
  xl = c * (x + yt * Sin(th));   yl = c * (yc - yt * Cos(th));

  Point(1000 + i) = {xu, yu, 0};
  If (i > 0 && i < n)
    Point(2000 + i) = {xl, yl, 0};
  EndIf

  If (i > 0)                     // arco recorrido, para repartir los nodos
    dS = Sqrt((xu - xAnt)^2 + (yu - yAnt)^2);
    If (i <= ks)        sTramo[0] += dS;
    ElseIf (i <= kr1)   sTramo[1] += dS;
    ElseIf (i <= kr2)   sTramo[2] += dS;
    Else                sTramo[3] += dS;
    EndIf
  EndIf
  xAnt = xu;  yAnt = yu;
EndFor

// Cuatro tramos por cara, del borde de ataque al de salida.
Spline(1) = {1000 : 1000 + ks};
Spline(2) = {1000 + ks : 1000 + kr1};
Spline(3) = {1000 + kr1 : 1000 + kr2};
Spline(4) = {1000 + kr2 : 1000 + n};

Spline(5) = {1000, 2001 : 2000 + ks};
Spline(6) = {2000 + ks : 2000 + kr1};
Spline(7) = {2000 + kr1 : 2000 + kr2};
Spline(8) = {2000 + kr2 : 2000 + n - 1, 1000 + n};

// Sólo quedan visibles los puntos que hacen falta para construir el dominio.
Hide { Point{1001 : 1000 + n - 1, 2001 : 2000 + n - 1}; }
Show { Point{1000 + ks, 1000 + kr1, 1000 + kr2, 2000 + ks, 2000 + kr1, 2000 + kr2}; }

// ---------------------------------------------- nodos a lo largo del perfil
// Los del 2.2.2: mandan las celdas del borde de ataque, de media cuerda y del borde de salida.
eL = sTramo[0];  eh1 = hBA;   ehN = hMed;  Call Empalme;
nT1 = eN;  rT1 = eR;
nT2 = 1 + Floor(sTramo[1] / hMed + 0.5);   rT2 = 1.0;
nT3 = 1 + Floor(sTramo[2] / hMed + 0.5);   rT3 = 1.0;
eL = sTramo[3];  eh1 = hMed;  ehN = hBS;   Call Empalme;
nT4 = eN;  rT4 = eR;

Printf("tramos del perfil: %g, %g, %g, %g nodos; %g celdas alrededor", nT1, nT2, nT3, nT4,
       2 * (nT1 + nT2 + nT3 + nT4 - 4));
