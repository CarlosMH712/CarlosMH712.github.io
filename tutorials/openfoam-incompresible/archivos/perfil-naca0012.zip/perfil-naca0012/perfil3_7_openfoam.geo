// Perfil NACA con el campo lejano a 500 cuerdas · paso 7: la extrusión y los grupos físicos
// Como en el 2.2.2, los índices de las caras no se copian a mano: se calculan a partir del
// lugar que ocupa cada curva en su Curve Loop.
Include "perfil3_6_malla.geo";

fluido2D[] = {1 : 20};

// Extrude devuelve, por cada superficie: la cara de enfrente, el volumen y una cara lateral
// por curva del lazo, en el orden en que se escribió el lazo (todos tienen cuatro curvas).
//   ext[6i]         cara de enfrente del bloque i        (i = 0, …, 19)
//   ext[6i + 1]     volumen
//   ext[6i + 2 + j] cara lateral de la curva j + 1 del lazo
ext[] = Extrude {0, 0, e} { Surface{fluido2D[]}; Layers{1}; Recombine; };

// Bloque y posición de la curva dentro de su lazo, para cada frontera.
perfilB[]  = {1, 2, 3, 4, 5, 6, 7, 8};             perfilC[]  = {1, 1, 1, 1, 1, 1, 1, 1};
entradaB[] = {11, 16};                             entradaC[] = {3, 3};
lejosB[]   = {12, 13, 14, 15, 17, 18, 19, 20};     lejosC[]   = {3, 3, 3, 3, 3, 3, 3, 3};
salidaB[]  = {9, 10, 15, 20};                      salidaC[]  = {2, 2, 2, 2};

Macro Caras
  caras[] = {};
  For iC In {0 : #bloques[] - 1}
    caras[] += {ext[6 * (bloques[iC] - 1) + 2 + (curvas[iC] - 1)]};
  EndFor
Return

// Cada Call va en su propio renglón (2.2.2).
bloques[] = perfilB[];  curvas[] = perfilC[];
Call Caras;
cPerfil[] = caras[];

bloques[] = entradaB[]; curvas[] = entradaC[];
Call Caras;
cEntrada[] = caras[];

bloques[] = lejosB[];   curvas[] = lejosC[];
Call Caras;
cLejos[] = caras[];

bloques[] = salidaB[];  curvas[] = salidaC[];
Call Caras;
cSalida[] = caras[];

traseras[] = {};  volumenes[] = {};
For i In {0 : #fluido2D[] - 1}
  traseras[]  += {ext[6 * i]};
  volumenes[] += {ext[6 * i + 1]};
EndFor

// El parche del perfil NO se llama wall: OpenFOAM agrupa por sí solo los parches de tipo wall
// y el nombre choca con ese grupo.
Physical Surface("airfoil")      = cPerfil[];
Physical Surface("inlet")        = cEntrada[];
Physical Surface("farfield")     = cLejos[];
Physical Surface("outlet")       = cSalida[];
Physical Surface("frontAndBack") = {fluido2D[], traseras[]};
Physical Volume("fluid")         = volumenes[];

Mesh.MshFileVersion = 2.2;   // gmshToFoam sólo lee MSH 2 ASCII
Mesh.Binary = 0;
