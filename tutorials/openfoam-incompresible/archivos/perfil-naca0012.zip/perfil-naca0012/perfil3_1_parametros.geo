// Perfil NACA con el campo lejano a 500 cuerdas · paso 1: los parámetros
// Continuación del Tutorial 2.2.2: la misma C de diez bloques queda como capa interior, a
// medio cuerda del perfil, y una segunda capa se abre en abanico hasta un arco de 500 cuerdas,
// como las mallas de validación de la NASA. Todo lo que se puede cambiar está aquí; cada
// constante se puede fijar desde la terminal:  gmsh perfil3_7_openfoam.geo -3 -setnumber R 100

SetFactory("Built-in");

// La extrusión del paso 7 empata los nodos por su posición, con una tolerancia de 1e-8 veces
// la diagonal del modelo. Con 1000 c de dominio son 1.4e-5 c, más que la primera celda (8e-6 c
// a Re = 6e6): Gmsh fundiría nodos de la pared y gmshToFoam abortaría («Did not determine new
// position for face»).
Geometry.Tolerance = 1e-12;

DefineConstant[
  // ---- perfil ----------------------------------------------------------
  naca   = {12,     Name "1Perfil/01Código NACA de 4 dígitos"},
  nasa   = {1,      Choices{0 = "NACA: borde cerrado",
                            1 = "NASA: borde agudo"},
                    Name "1Perfil/02Definición del espesor"},
  c      = {1.0,    Name "1Perfil/03Cuerda c (m)"},
  n      = {120,    Name "1Perfil/04Intervalos por cara"},
  xs     = {0.20,   Name "1Perfil/05Estación 1, fin de la nariz (c)"},
  xr1    = {0.55,   Name "1Perfil/06Estación 2 (c)"},
  xr2    = {0.75,   Name "1Perfil/07Estación 3 (c)"},
  hBA    = {0.0005, Name "1Perfil/08Celda en el borde de ataque (c)"},
  hMed   = {0.015,  Name "1Perfil/09Celda a media cuerda (c)"},
  hBS    = {0.002,  Name "1Perfil/10Celda en el borde de salida (c)"},

  // ---- dominio ---------------------------------------------------------
  // R se mide desde el borde de salida, centro del arco; «abanico» es el arco que ocupan
  // juntos los bloques sobre el perfil (de la estación 1 al borde de salida).
  R       = {500.0, Name "2Dominio/1Radio del campo lejano (c)"},
  L       = {500.0, Name "2Dominio/2Estela hasta la salida (c)"},
  abanico = {15.0,  Name "2Dominio/3Abanico sobre el perfil (grados)"},
  hFar    = {50.0,  Name "2Dominio/4Celda en el campo lejano (c)"},
  hSalida = {0.06,  Name "2Dominio/5Celda vertical en la salida (c)"},
  hPiso   = {0.5,   Name "2Dominio/6Espesor de la capa interior (c)"},

  // ---- la primera celda, a partir de y+ --------------------------------
  rho    = {1.225,    Name "3y+/1Densidad ρ (kg m⁻³)"},
  mu     = {1.789e-5, Name "3y+/2Viscosidad μ (Pa s)"},
  Uinf   = {87.6245,  Name "3y+/3Velocidad U∞ (m s⁻¹)"},
  yplus  = {1.0,      Name "3y+/4y+ buscado"},

  // ---- extrusión para OpenFOAM ----------------------------------------
  e      = {0.01, Name "4OpenFOAM/1Espesor de la extrusión (m)"}
];

// ---------------------------------------------------------------- perfil
// Los dígitos del código: curvatura máxima m, su posición p y el espesor t.
Md = Floor(naca / 1000);
Pd = Floor((naca - 1000 * Md) / 100);
Td = naca - 1000 * Md - 100 * Pd;
m = Md / 100.0;
p = Pd / 10.0;
t = Td / 100.0;

// Índices de las tres estaciones de control (espaciado coseno invertido, 2.2.2).
ks  = Floor(n / Pi * Acos(1.0 - 2.0 * xs)  + 0.5);
kr1 = Floor(n / Pi * Acos(1.0 - 2.0 * xr1) + 0.5);
kr2 = Floor(n / Pi * Acos(1.0 - 2.0 * xr2) + 0.5);

// ------------------------------------------------- primera celda desde y+
// Placa plana turbulenta: Cf = 0.074 Re^(-1/5). y+ mide la distancia del CENTRO de la primera
// celda a la pared: la altura de la celda es el doble.
nu   = mu / rho;
Rec  = Uinf * c / nu;
Cf   = 0.074 / Rec^0.2;
utau = Uinf * Sqrt(Cf / 2.0);
y1 = yplus * nu / utau;
hw = 2.0 * y1;

// ------------------------------------------- las dos macros del 2.2.2
// Empalme: reparte eL en celdas que van de eh1 a ehN; devuelve la razón eR y los nodos eN.
Macro Empalme
  eR = (eL - eh1) / (eL - ehN);
  eN = 2 + Floor(Log(ehN / eh1) / Log(eR) + 0.5);
Return

// Razon: con los nodos eN ya fijos, busca por bisección la razón eR que reparte eL empezando
// en eh1.
Macro Razon
  rA = 1.0 + 1.e-9;  rB = 3.0;
  For iter In {1:80}
    rM = 0.5 * (rA + rB);
    sM = eh1 * (rM^(eN - 1) - 1.0) / (rM - 1.0);
    If (sM < eL)
      rA = rM;
    Else
      rB = rM;
    EndIf
  EndFor
  eR = 0.5 * (rA + rB);
Return

// Radial: de la pared al campo lejano, una sola progresión desde hw. En el paso 3 se parte en
// dos: la capa interior lleva sus primeros nodos y el abanico el resto.
eL = R;  eh1 = hw;  ehN = hFar;  Call Empalme;
nRadial = eN;  rRadial = eR;

// Cuántas de esas celdas caen dentro de la capa límite de una placa plana a esta cuerda.
dBL = 0.37 * c / Rec^0.2;
nBL = Log(1.0 + dBL * (rRadial - 1.0) / hw) / Log(rRadial);

// Axial en la estela: arranca con la celda del borde de salida del perfil.
eL = L;  eh1 = hBS;  ehN = hFar;  Call Empalme;
nEstela = eN;  rEstela = eR;

Printf("Re_c = %g   Cf = %g   u_tau = %g", Rec, Cf, utau);
Printf("y+ = %g  ->  centro de la primera celda y1 = %g c, altura hw = %g c", yplus, y1, hw);
Printf("radial: %g nodos con progresión %g (de %g c a %g c)", nRadial, rRadial, hw, hFar);
Printf("capa límite estimada %g c: %g celdas dentro", dBL, nBL);
Printf("estela: %g nodos con progresión %g (de %g c a %g c)", nEstela, rEstela, hBS, hFar);
