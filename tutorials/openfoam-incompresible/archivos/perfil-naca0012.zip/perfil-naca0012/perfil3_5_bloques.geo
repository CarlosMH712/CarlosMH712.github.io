// Perfil NACA con el campo lejano a 500 cuerdas · paso 5: los veinte bloques
// Cada lazo empieza en la curva de abajo (el perfil, el corte de estela o la C pequeña) y da
// la vuelta.
Include "perfil3_4_abanico.geo";

// La capa interior: los diez bloques del 2.2.2, con sus mismos lazos.
Curve Loop(1) = {1, 23, -11, -22};   Plane Surface(1) = {1};
Curve Loop(2) = {2, 24, -13, -23};   Plane Surface(2) = {2};
Curve Loop(3) = {3, 25, -14, -24};   Plane Surface(3) = {3};
Curve Loop(4) = {4, 26, -15, -25};   Plane Surface(4) = {4};
Curve Loop(5) = {5, 27, -12, -22};   Plane Surface(5) = {5};
Curve Loop(6) = {6, 28, -17, -27};   Plane Surface(6) = {6};
Curve Loop(7) = {7, 29, -18, -28};   Plane Surface(7) = {7};
Curve Loop(8) = {8, 30, -19, -29};   Plane Surface(8) = {8};
Curve Loop(9)  = {21, 31, -16, -26};  Plane Surface(9)  = {9};
Curve Loop(10) = {21, 32, -20, -30};  Plane Surface(10) = {10};

// La capa exterior: un bloque frente a cada curva de la C pequeña.
Curve Loop(11) = {11, 53, -41, -51};  Plane Surface(11) = {11};
Curve Loop(12) = {13, 55, -43, -53};  Plane Surface(12) = {12};
Curve Loop(13) = {14, 57, -44, -55};  Plane Surface(13) = {13};
Curve Loop(14) = {15, 59, -45, -57};  Plane Surface(14) = {14};
Curve Loop(15) = {16, 61, -46, -59};  Plane Surface(15) = {15};
Curve Loop(16) = {12, 54, -42, -51};  Plane Surface(16) = {16};
Curve Loop(17) = {17, 56, -47, -54};  Plane Surface(17) = {17};
Curve Loop(18) = {18, 58, -48, -56};  Plane Surface(18) = {18};
Curve Loop(19) = {19, 60, -49, -58};  Plane Surface(19) = {19};
Curve Loop(20) = {20, 62, -50, -60};  Plane Surface(20) = {20};
