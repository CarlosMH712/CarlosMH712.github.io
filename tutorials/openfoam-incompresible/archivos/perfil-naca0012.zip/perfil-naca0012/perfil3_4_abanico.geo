// Perfil NACA con el campo lejano a 500 cuerdas · paso 4: la capa exterior, en abanico
// De la C pequeña del paso 3 a un arco de radio R con centro en el borde de salida. En el
// 2.2.2 las radiales de las estaciones suben en vertical hasta una recta y = R, y las columnas
// de celdas sobre el perfil conservan su ancho hasta el campo lejano: a 100 c serían de
// 0.002 × 10 c, con 82° de no ortogonalidad. Aquí se abren en abanico.
Include "perfil3_3_capa_interior.geo";

// Los bloques sobre el perfil (de la estación 1 al borde de salida) ocupan juntos «abanico»
// grados del arco, a partir de 90°, en proporción a sus celdas: en el campo lejano todas miden
// lo mismo, hArco. La nariz se queda con el resto, hasta 180°.
cArriba = (nT2 - 1) + (nT3 - 1) + (nT4 - 1);
th9 = Pi / 2;
th7 = th9 + abanico * Pi / 180 * (nT4 - 1) / cArriba;
th5 = th7 + abanico * Pi / 180 * (nT3 - 1) / cArriba;
th3 = th9 + abanico * Pi / 180;
hArco = R * abanico * Pi / 180 / cArriba;

Point(51) = {c - R, 0, 0};                                      // frente
Point(53) = {c + R * Cos(th3), R * Sin(th3), 0};
Point(54) = {c + R * Cos(th3), -R * Sin(th3), 0};
Point(55) = {c + R * Cos(th5), R * Sin(th5), 0};
Point(56) = {c + R * Cos(th5), -R * Sin(th5), 0};
Point(57) = {c + R * Cos(th7), R * Sin(th7), 0};
Point(58) = {c + R * Cos(th7), -R * Sin(th7), 0};
Point(59) = {c, R, 0};     Point(60) = {c, -R, 0};
Point(61) = {xo, R, 0};    Point(62) = {xo, -R, 0};

// El arco tiene su centro en el borde de salida; arriba y abajo de la estela, rectas hasta la
// salida.
Circle(41) = {51, cBS, 53};   Circle(42) = {51, cBS, 54};
Circle(43) = {53, cBS, 55};   Circle(44) = {55, cBS, 57};   Circle(45) = {57, cBS, 59};
Line(46) = {59, 61};
Circle(47) = {54, cBS, 56};   Circle(48) = {56, cBS, 58};   Circle(49) = {58, cBS, 60};
Line(50) = {60, 62};

// Las radiales del abanico: de cada esquina de la C pequeña a su punto del arco.
Line(51) = {1, 51};
Line(53) = {3, 53};  Line(55) = {5, 55};  Line(57) = {7, 57};
Line(59) = {9, 59};  Line(61) = {11, 61};
Line(54) = {4, 54};  Line(56) = {6, 56};  Line(58) = {8, 58};
Line(60) = {10, 60}; Line(62) = {12, 62};

Printf("arco: estaciones a %g, %g, %g grados; celda %g c sobre el perfil", th3 * 180 / Pi,
       th5 * 180 / Pi, th7 * 180 / Pi, hArco);
