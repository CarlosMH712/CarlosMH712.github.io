// Perfil NACA con el campo lejano a 500 cuerdas · paso 6: los nodos y la malla
// Ningún número se escribe a mano: todos salen de los pasos anteriores.
//
// La regla que ordena todo: Gmsh reparte el interior de un bloque transfinito con el PROMEDIO
// del reparto de los dos lados opuestos (meshGFaceTransfinite.cpp, «symmetric»), y eso sólo
// sale bien si a lo más un par de lados opuestos reparte distinto. En la capa interior
// difieren sólo los lados verticales de la estela (la radial del borde de salida empieza en hw
// y la salida en hSalida); en el abanico, sólo los de abajo y arriba (la C pequeña y el arco).
// Un solo bloque de estela del perfil al arco tendría los dos pares distintos, y sus líneas
// saldrían en abanico desde el borde de salida (61° de no ortogonalidad).
Include "perfil3_5_bloques.geo";

// ---- capa interior, como el 2.2.2 --------------------------------------
// Cada tramo del perfil y la recta que tiene enfrente llevan los mismos nodos y la misma
// progresión; la media elipse empieza arriba con la celda de los tramos 2 y 3 y crece hacia el
// frente.
hArriba = sTramo[1] / (nT2 - 1);
aE = xc + H1;  bE = pS[1] + H1;
// la longitud de la media elipse, con la fórmula de Ramanujan
sElipse = Pi * (3.0 * (aE + bE) - Sqrt((3.0 * aE + bE) * (aE + 3.0 * bE))) / 4.0;
eL = sElipse;  eh1 = hArriba;  eN = nT1;  Call Razon;
rEntrada = 1.0 / eR;

// ---- abanico -------------------------------------------------------------
// El arco de la nariz termina en el punto 53 con la celda hArco y crece hacia el frente; el
// tope de la estela empieza con hArco en el punto 59 y crece hacia la salida. Así, a lo largo
// de toda la frontera exterior, las celdas vecinas miden lo mismo.
eL = R * (Pi - th3);  eh1 = hArco;  eN = nT1;  Call Razon;
rNariz = 1.0 / eR;
eL = L;  eh1 = hArco;  eN = nEstela;  Call Razon;
rTope = eR;

Transfinite Curve {1, 5}           = nT1 Using Progression rT1;
Transfinite Curve {11, 12}         = nT1 Using Progression rEntrada;
Transfinite Curve {2, 6, 13, 17}   = nT2;
Transfinite Curve {3, 7, 14, 18}   = nT3;
Transfinite Curve {4, 8, 15, 19}   = nT4 Using Progression rT4;
Transfinite Curve {22:30}          = K + 1 Using Progression rRadial;      // hasta el nodo K
Transfinite Curve {21, 16, 20}     = nEstela Using Progression rEstela;
Transfinite Curve {31, 32}         = K + 1 Using Progression rPiso;

Transfinite Curve {41, 42}         = nT1 Using Progression rNariz;
Transfinite Curve {43, 47}         = nT2;
Transfinite Curve {44, 48}         = nT3;
Transfinite Curve {45, 49}         = nT4;
Transfinite Curve {46, 50}         = nEstela Using Progression rTope;
Transfinite Curve {51, 53:62}      = nRadial - K Using Progression rRadial; // desde el K

Transfinite Surface {1:20};
Recombine Surface {1:20};

// La malla estructurada no se suaviza: el suavizado mueve los nodos que Transfinite acaba de
// colocar.
Mesh.Smoothing = 0;

Printf("nariz: progresión %g, celda en el frente %g c",
       rNariz, hArco * (1 / rNariz)^(nT1 - 2));
Printf("tope de la estela: progresión %g, celda en la salida %g c",
       rTope, hArco * rTope^(nEstela - 2));
