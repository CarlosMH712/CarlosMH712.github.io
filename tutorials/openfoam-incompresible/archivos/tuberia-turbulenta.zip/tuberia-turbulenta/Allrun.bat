@echo off
rem Tuberia turbulenta, Re = 50 000, k-omega SST, en blueCFD-Core 2024 (OpenFOAM 12).
rem Uso, desde la terminal cmd de blueCFD y en la carpeta del caso:  Allrun.bat
rem Hace lo mismo que la receta de la guia: malla con Gmsh, gmshToFoam, giro de la malla al eje x, tipo del
rem parche de la pared, checkMesh y foamRun, en serie. Gmsh tiene que estar en el PATH.
setlocal
cd /d %~dp0

where gmsh > nul 2>&1 || (echo No se encuentra gmsh: agregue su carpeta al PATH, por ejemplo& echo     set PATH=%%PATH%%;C:\gmsh-4.15.2-Windows64& exit /b 1)
call gmsh tuberia.geo -3 -setnumber regimen 1 -setnumber Re 50000 -setnumber yplus 1 -o tuberia.msh -log log.gmsh > nul 2>&1 || goto fallo
gmshToFoam tuberia.msh > log.gmshToFoam 2>&1 || goto fallo
rem el eje de la tuberia, de z a x: blueCFD-Core 2024 (OpenFOAM 12) resuelve mal los flujos a lo largo de z
transformPoints "Ry=90" > log.transformPoints 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/walls/type -set wall > log.foamDictionary 2>&1 || goto fallo
checkMesh > log.checkMesh 2>&1 || goto fallo
foamRun > log.foamRun 2>&1 || goto fallo
echo Listo. Sondas en postProcessing\sondas\0, eje y perfil en postProcessing\eje y postProcessing\radial.
goto :eof

:fallo
echo Fallo un paso: revisa el ultimo log.* de la carpeta del caso.
exit /b 1
