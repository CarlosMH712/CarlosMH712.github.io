#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Gráfica de la polar: C_L contra alfa y C_D contra C_L, con Ladson (referencia/ladson.dat) y CFL3D (referencia/cfl3d.dat).
Escribe polar.svg, que se abre con doble clic en el navegador. Sólo Python (el de blueCFD sirve):

    python graficar_polar.py
"""
import os

AQUI = os.path.dirname(os.path.abspath(__file__))


def leer(ruta, columnas):
    filas = []
    for l in open(ruta, encoding="utf-8"):
        if l.strip() and not l.startswith("#"):
            p = l.split()
            try:
                filas.append([float(p[i]) for i in columnas])
            except (ValueError, IndexError):
                pass
    return filas


def sub(texto):
    """C_L → C con L como subíndice (en SVG)."""
    return texto.replace("C_L", 'C<tspan baseline-shift="sub" font-size="10">L</tspan>').replace(
        "C_D", 'C<tspan baseline-shift="sub" font-size="10">D</tspan>')


def panel(x0, y0, w, h, xr, yr, xt, yt, xlab, ylab, titulo, series):
    """Un recuadro con ejes, marcas y las series [(puntos, color, forma, rótulo)]. forma: 'linea', 'cuadro' o 'circulo'."""
    X = lambda v: x0 + (v - xr[0]) / (xr[1] - xr[0]) * w
    Y = lambda v: y0 + h - (v - yr[0]) / (yr[1] - yr[0]) * h
    s = ['<text x="%g" y="%g" font-size="15" font-weight="bold">%s</text>' % (x0, y0 - 18, titulo)]
    for v in yt:
        s.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="#dde3ea"/><text x="%g" y="%g" font-size="12" text-anchor="end">%g</text>'
                 % (x0, Y(v), x0 + w, Y(v), x0 - 6, Y(v) + 4, v))
    for v in xt:
        s.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="#dde3ea"/><text x="%g" y="%g" font-size="12" text-anchor="middle">%g</text>'
                 % (X(v), y0, X(v), y0 + h, X(v), y0 + h + 18, v))
    s.append('<rect x="%g" y="%g" width="%g" height="%g" fill="none" stroke="#333"/>' % (x0, y0, w, h))
    s.append('<text x="%g" y="%g" font-size="13" text-anchor="middle">%s</text>' % (x0 + w / 2, y0 + h + 38, sub(xlab)))
    s.append('<text x="%g" y="%g" font-size="13" text-anchor="middle" transform="rotate(-90 %g %g)">%s</text>'
             % (x0 - 44, y0 + h / 2, x0 - 44, y0 + h / 2, sub(ylab)))
    for k, (pts, color, forma, rotulo) in enumerate(series):
        pts = [(X(a), Y(b)) for a, b in pts if xr[0] <= a <= xr[1] and yr[0] <= b <= yr[1]]
        if forma == "linea" and len(pts) > 1:
            s.append('<polyline points="%s" fill="none" stroke="%s" stroke-width="2"/>' % (" ".join("%g,%g" % p for p in pts), color))
        for px, py in pts:
            if forma == "cuadro":
                s.append('<rect x="%g" y="%g" width="7" height="7" fill="none" stroke="%s"/>' % (px - 3.5, py - 3.5, color))
            else:
                s.append('<circle cx="%g" cy="%g" r="3.8" fill="%s"/>' % (px, py, color))
        ly = y0 + 18 + 18 * k
        s.append('<text x="%g" y="%g" font-size="12">%s</text>' % (x0 + 38, ly + 4, rotulo))
        if forma == "linea":
            s.append('<line x1="%g" y1="%g" x2="%g" y2="%g" stroke="%s" stroke-width="2"/>' % (x0 + 8, ly, x0 + 30, ly, color))
        elif forma == "cuadro":
            s.append('<rect x="%g" y="%g" width="7" height="7" fill="none" stroke="%s"/>' % (x0 + 15, ly - 3.5, color))
        else:
            s.append('<circle cx="%g" cy="%g" r="3.8" fill="%s"/>' % (x0 + 19, ly, color))
    return s


def main():
    nuestra = leer(os.path.join(AQUI, "polar.dat"), (0, 1, 2))
    ladson = leer(os.path.join(AQUI, "referencia", "ladson.dat"), (0, 1, 2))
    cfl3d = leer(os.path.join(AQUI, "referencia", "cfl3d.dat"), (0, 1, 2))
    azul, rojo, gris = "#0b5a8f", "#c0392b", "#555555"
    s = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 440" font-family="Segoe UI, Arial, sans-serif">',
         '<rect width="960" height="440" fill="white"/>']
    s += panel(70, 50, 380, 310, (-2, 20), (-0.2, 1.8), range(0, 21, 4), (0, 0.4, 0.8, 1.2, 1.6), "α (°)", "C_L",
               "Sustentación", [([(a, l) for a, l, d in ladson], gris, "cuadro", "Ladson (experimento)"),
                                ([(a, l) for a, l, d in cfl3d], rojo, "circulo", "CFL3D (NASA)"),
                                ([(a, l) for a, l, d in nuestra], azul, "linea", "OpenFOAM")])
    s += panel(540, 50, 380, 310, (0, 1.8), (0, 0.05), (0, 0.4, 0.8, 1.2, 1.6), (0, 0.01, 0.02, 0.03, 0.04, 0.05), "C_L", "C_D",
               "Resistencia", [([(l, d) for a, l, d in ladson], gris, "cuadro", "Ladson (experimento)"),
                               ([(l, d) for a, l, d in cfl3d], rojo, "circulo", "CFL3D (NASA)"),
                               ([(l, d) for a, l, d in nuestra], azul, "linea", "OpenFOAM")])
    s.append("</svg>")
    ruta = os.path.join(AQUI, "polar.svg")
    open(ruta, "w", encoding="utf-8").write("\n".join(s))
    print("escrito:", ruta)


if __name__ == "__main__":
    main()
