# -*- coding: utf-8 -*-
"""
Cuadros de la animación del perfil en pérdida (tutorial 2.5), a partir de las superficies que la función `animacion`
de system/functions guarda cada 20 pasos de t = 30 a 40 (postProcessing/animacion/<t>/): el perfil (parche airfoil,
del propio caso) en gris y, según la vista,

    vorticidad   el plano medio de la envergadura coloreado por la vorticidad ω_z, visto de frente (proyección paralela)
    remolinos    la isosuperficie Q coloreada por |U|, en perspectiva

Un PNG por tiempo (f000.png, f001.png…); se unen con ffmpeg.

    pvbatch animacion_perfil.py <caso> <carpeta de salida> <rótulo> <vista> [cada]

[cada]: usar uno de cada n tiempos (1 por omisión).
"""
import os
import sys

import paraview.simple
from paraview.simple import *  # noqa: F401,F403

paraview.simple._DisableFirstRenderCameraReset()

caso, out, rotulo, vista = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
cada = int(sys.argv[5]) if len(sys.argv) > 5 else 1
os.makedirs(out, exist_ok=True)
carpeta = os.path.join(caso, "postProcessing", "animacion")
tiempos = sorted((d for d in os.listdir(carpeta) if os.path.isdir(os.path.join(carpeta, d))), key=float)[::cada]
superficie = "remolinos.vtk" if vista == "remolinos" else "planoMedio.vtk"
open(os.path.join(caso, "caso.foam"), "a").close()

datos = LegacyVTKReader(FileNames=[os.path.join(carpeta, tiempos[0], superficie)])
if vista == "remolinos":
    fuente = GenerateSurfaceNormals(Input=datos)  # sombreado suave: sin normales, los triángulos se ven facetados
else:
    fuente = Clip(Input=datos)                  # el plano sólo alrededor del perfil y su estela
    fuente.ClipType = "Box"
    fuente.ClipType.Position = [-1.5, -2.0, -1]
    fuente.ClipType.Length = [9.5, 4.0, 3]
    fuente.Invert = 1
    fuente.Crinkleclip = 0
    try:
        fuente.Exact = 1
    except AttributeError:
        pass

r = OpenFOAMReader(FileName=caso + "/caso.foam")
r.CaseType = "Decomposed Case" if os.path.isdir(os.path.join(caso, "processor0")) else "Reconstructed Case"
r.MeshRegions = ["patch/airfoil"]
r.CellArrays = []
r.UpdatePipelineInformation()
if vista == "remolinos":
    perfil = r
else:                                           # visto de frente, el parche del perfil es una línea: se rellena el
    corte = Slice(Input=r)                      # contorno en el plano medio
    corte.SliceType = "Plane"
    corte.SliceType.Origin = [0, 0, 0.5]
    corte.SliceType.Normal = [0, 0, 1]
    perfil = Delaunay2D(Input=corte)

v = CreateView("RenderView")
v.ViewSize = [1600, 720]
v.Background = [1, 1, 1]
try:
    v.UseColorPaletteForBackground = 0
except AttributeError:
    pass
v.OrientationAxesVisibility = 0

df = Show(fuente, v)
if vista == "remolinos":
    ColorBy(df, ("POINTS", "U", "Magnitude"))
    lut = GetColorTransferFunction("U")
    lut.ApplyPreset("Turbo", True)
    lut.RescaleTransferFunction(0.0, 2.0)
    titulo = "|U| / U"
else:
    ColorBy(df, ("POINTS", "vorticity", "Z"))
    lut = GetColorTransferFunction("vorticity")
    lut.ApplyPreset("Cool to Warm", True)
    lut.RescaleTransferFunction(-5.0, 5.0)      # la estela: ±20 sólo deja ver las capas junto al perfil
    titulo = "vorticidad z (U/c)"               # la fuente de ParaView no tiene ω
    df.Ambient = 1.0                            # sin sombreado: los colores del mapa tal cual
    df.Diffuse = 0.0
lut.AutomaticRescaleRangeMode = "Never"
df.SetScalarBarVisibility(v, True)
barra = GetScalarBar(lut, v)
barra.Title = titulo
barra.ComponentTitle = ""
barra.TitleColor = barra.LabelColor = [0, 0, 0]
barra.RangeLabelFormat = "%.0f"
dp = Show(perfil, v)
dp.ColorArrayName = ["POINTS", ""]             # color sólido (ColorBy(dp, None) falla sin arreglos en el lector)
dp.DiffuseColor = [0.35, 0.36, 0.40]
dp.Specular = 0.3
texto = Text()
dt = Show(texto, v)
dt.Color = [0, 0, 0]
dt.FontSize = 24
dt.WindowLocation = "Upper Left Corner"

if vista == "remolinos":
    v.CameraParallelProjection = 0
    v.CameraPosition = [-0.8, 1.9, 6.6]         # más de lado que en calibrar_q.py: desde arriba, la estela del DDES
    v.CameraFocalPoint = [2.8, 0.1, 0.5]       # sube en la imagen y se salía del cuadro
    v.CameraViewUp = [0, 1, 0]
    v.CameraViewAngle = 30
else:
    v.CameraParallelProjection = 1
    v.CameraPosition = [3.0, -0.2, 20]
    v.CameraFocalPoint = [3.0, -0.2, 0.5]
    v.CameraViewUp = [0, 1, 0]
    v.CameraParallelScale = 1.9

for i, t in enumerate(tiempos):
    datos.FileNames = [os.path.join(carpeta, t, superficie)]
    texto.Text = "%s   t = %.2f c/U" % (rotulo, float(t))
    Render(v)
    SaveScreenshot(os.path.join(out, "f%03d.png" % i), v)
print("cuadros:", len(tiempos))
