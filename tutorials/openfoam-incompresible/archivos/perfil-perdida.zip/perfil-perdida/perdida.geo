// Perfil NACA 0012 en pérdida profunda (45°): malla 2D híbrida y su extrusión en la envergadura
// Exploración de los tutoriales 2.4 (URANS, DDES y LES) y 2.5 (animación) de «OpenFOAM · Flujo incompresible».
//
// El perfil se gira, no la corriente: el flujo va en +x y la estela queda dentro de las cajas de refinamiento.
// Capa de cuadriláteros pegada al perfil (campo BoundaryLayer), cuadriláteros recombinados en el resto, dos cajas
// de tamaño uniforme para la estela (la zona LES del DDES) y la extrusión en z:
//
//   gmsh perdida.geo -3 -o perdida.msh                         3D, envergadura de una cuerda
//   gmsh perdida.geo -3 -setnumber nz 1 -setnumber b 0.01 ...  2D (una capa) para el URANS
//
SetFactory("Built-in");
Geometry.Tolerance = 1e-12;

DefineConstant[
  alfa  = {45,     Name "1Perfil/1Ángulo de ataque (grados)"},
  c     = {1.0,    Name "1Perfil/2Cuerda (m)"},
  np    = {120,    Name "1Perfil/3Puntos de la definición por cara"},
  nP    = {121,    Name "1Perfil/4Nodos por cara en la malla"},
  bump  = {0.5,    Name "1Perfil/5Agrupamiento en los bordes (Bump: 1 = uniforme)"},
  xBS   = {1.0,    Name "1Perfil/6Corte del borde de salida (x/c)"},
  y1    = {1e-3,   Name "2Capa/1Primera celda (c): y+ ≈ 25 a Re = 5e5, con función de pared"},
  razon = {1.2,    Name "2Capa/2Razón de crecimiento"},
  espC  = {0.008,  Name "2Capa/3Espesor de la capa de cuadriláteros (c)"},
  hPa   = {0.006,  Name "3Tamaños/1Celda junto al perfil (c)"},
  hIn   = {0.025,  Name "3Tamaños/2Celda en la caja de la estela cercana (c)"},
  hOut  = {0.06,   Name "3Tamaños/3Celda en la caja de la estela lejana (c)"},
  hFar  = {1.0,    Name "3Tamaños/4Celda en el campo lejano (c)"},
  xIn   = {4.0,    Name "4Cajas/1Fin de la caja cercana (c)"},
  yIn   = {1.2,    Name "4Cajas/2Semialtura de la caja cercana (c)"},
  xOut  = {12.0,   Name "4Cajas/3Fin de la caja lejana (c)"},
  yOut  = {2.5,    Name "4Cajas/4Semialtura de la caja lejana (c)"},
  Lent  = {15.0,   Name "5Dominio/1Entrada, delante del perfil (c)"},
  Lsal  = {30.0,   Name "5Dominio/2Salida, detrás del perfil (c)"},
  H     = {15.0,   Name "5Dominio/3Semialtura (c)"},
  b     = {1.0,    Name "6Envergadura/1Envergadura (c)"},
  nz    = {32,     Name "6Envergadura/2Capas en la envergadura"}
];

// ---- el perfil: NACA 0012 estándar (−0.1015 x⁴), espaciado coseno ---------------------------------------
// El perfil se corta en x = xBS y se cierra con un semicírculo del medio espesor que tiene ahí. Un borde agudo
// obliga a Gmsh a poner un abanico de celdas diminutas en la punta (4·10⁻⁵ c por lado), y con ellas el paso de
// tiempo baja a 10⁻⁵ c/U. Con el borde estándar (xBS = 1) el semicírculo tiene 0.00126 c de radio. Cortado en
// 0.99 c (radio de 0.00265 c), el paso de tiempo sólo sube un 14 %: lo fijan también las celdas del borde de ataque.
t = 0.12;
pu[] = {};  pl[] = {};
For i In {0 : np}
  be = Pi * i / np;
  x = xBS * 0.5 * (1 - Cos(be));
  y = 5 * t * (0.2969 * Sqrt(x) - 0.1260 * x - 0.3516 * x^2 + 0.2843 * x^3 - 0.1015 * x^4);
  If (i == 0)
    p = newp;  Point(p) = {0, 0, 0};
    pu[] += {p};  pl[] += {p};
  Else
    p = newp;  Point(p) = {c * x,  c * y, 0};  pu[] += {p};
    q = newp;  Point(q) = {c * x, -c * y, 0};  pl[] += {q};
  EndIf
EndFor
rBS = c * y;                          // medio espesor en el corte: 0.00126 c con xBS = 1
pC = newp;  Point(pC) = {xBS * c, 0, 0};
pP = newp;  Point(pP) = {xBS * c + rBS, 0, 0};
cU = newc;  Spline(cU) = pu[];        // extradós, del borde de ataque al de salida
cL = newc;  Spline(cL) = pl[];        // intradós, ídem
a1 = newc;  Circle(a1) = {pu[np], pC, pP};   // el semicírculo del borde de salida, en dos cuartos
a2 = newc;  Circle(a2) = {pP, pC, pl[np]};

// nariz arriba: giro de −α alrededor del cuarto de cuerda (la corriente va en +x)
Rotate {{0, 0, 1}, {0.25 * c, 0, 0}, -alfa * Pi / 180} { Curve{cU, cL, a1, a2}; }

Transfinite Curve{cU, cL} = nP Using Bump bump;    // nodos agrupados en los dos bordes
Transfinite Curve{a1, a2} = 2;                    // una celda por cuarto de círculo

// ---- el dominio: rectángulo ------------------------------------------------------------------------------
q1 = newp;  Point(q1) = {-Lent * c, -H * c, 0};
q2 = newp;  Point(q2) = { Lsal * c, -H * c, 0};
q3 = newp;  Point(q3) = { Lsal * c,  H * c, 0};
q4 = newp;  Point(q4) = {-Lent * c,  H * c, 0};
lAb  = newc;  Line(lAb)  = {q1, q2};
lSal = newc;  Line(lSal) = {q2, q3};
lAr  = newc;  Line(lAr)  = {q3, q4};
lEnt = newc;  Line(lEnt) = {q4, q1};

exterior = newcl;  Curve Loop(exterior) = {lAb, lSal, lAr, lEnt};
interior = newcl;  Curve Loop(interior) = {cU, a1, a2, -cL};
fluido = news;     Plane Surface(fluido) = {exterior, interior};

// ---- tamaños ---------------------------------------------------------------------------------------------
// El algoritmo de cuadriláteros (8) entrega celdas de la mitad del tamaño pedido: los campos piden el doble.
fq = 2;
Field[1] = BoundaryLayer;
Field[1].CurvesList = {cU, cL, a1, a2};
Field[1].Size = y1 * c;
Field[1].Ratio = razon;
Field[1].Thickness = espC * c;
Field[1].Quads = 1;
BoundaryLayer Field = 1;

Field[2] = Distance;
Field[2].CurvesList = {cU, cL, a1, a2};
Field[2].Sampling = 400;
Field[3] = Threshold;                 // de hPa junto al perfil a hIn a 0.3 c
Field[3].InField = 2;
Field[3].SizeMin = fq * hPa * c;
Field[3].SizeMax = fq * hFar * c;
Field[3].DistMin = 0.02 * c;
Field[3].DistMax = 0.3 * c * hFar / hIn;

Field[4] = Box;                       // la estela cercana: celdas casi cúbicas de hIn (con dz = b/nz)
Field[4].VIn = fq * hIn * c;   Field[4].VOut = fq * hFar * c;
Field[4].XMin = -0.8 * c; Field[4].XMax = xIn * c;
Field[4].YMin = -yIn * c; Field[4].YMax = yIn * c;
Field[4].Thickness = 0.5 * c;

Field[5] = Box;                       // la estela lejana
Field[5].VIn = fq * hOut * c;  Field[5].VOut = fq * hFar * c;
Field[5].XMin = -2.0 * c; Field[5].XMax = xOut * c;
Field[5].YMin = -yOut * c; Field[5].YMax = yOut * c;
Field[5].Thickness = 2.0 * c;

Field[6] = Min;
Field[6].FieldsList = {3, 4, 5};
Background Field = 6;

Mesh.MeshSizeExtendFromBoundary = 0;
Mesh.MeshSizeFromPoints = 0;
Mesh.MeshSizeFromCurvature = 0;
Mesh.Algorithm = 8;                   // frontal-Delaunay para cuadriláteros
Mesh.RecombineAll = 1;
Mesh.RecombinationAlgorithm = 1;      // blossom

// ---- la extrusión en la envergadura y los grupos físicos -------------------------------------------------
// ext[0] cara de enfrente, ext[1] volumen, ext[2..] una cara lateral por curva, en el orden de los lazos:
// abajo, salida, arriba, entrada; extradós, los dos cuartos de círculo e intradós
ext[] = Extrude {0, 0, b * c} { Surface{fluido}; Layers{nz}; Recombine; };

Physical Surface("airfoil")  = {ext[6], ext[7], ext[8], ext[9]};
Physical Surface("inlet")    = {ext[5]};
Physical Surface("outlet")   = {ext[3]};
Physical Surface("sides")    = {ext[2], ext[4]};
Physical Surface("back")     = {fluido};
Physical Surface("front")    = {ext[0]};
Physical Volume("fluid")     = {ext[1]};

Mesh.MshFileVersion = 2.2;
