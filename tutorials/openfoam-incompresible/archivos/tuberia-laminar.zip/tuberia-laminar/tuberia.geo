// Tubería recta parametrizada (tutorial 3.1.2): la sección en O de 9 bloques del 3.1.1, con la primera celda
// calculada desde y+ y la longitud desde el número de Reynolds. Unidades: metros.
// Cada parámetro se cambia en el panel «Tubería» de la interfaz o desde la terminal. En los rótulos no puede ir
// una diagonal: Gmsh la toma como separador de ramas del panel.
//   gmsh tuberia.geo -3 -setnumber regimen 1 -setnumber Re 50000 -o tuberia.msh

SetFactory("Built-in");

DefineConstant[
  regimen = {0,     Choices{0 = "Laminar", 1 = "Turbulento"}, Name "Tubería/1Régimen"},
  Re      = {500,   Name "Tubería/2Número de Reynolds"},
  D       = {1,     Name "Tubería/3Diámetro D (m)"},
  yplus   = {0.2,   Name "Tubería/4y+ de la primera celda"},
  gmax    = {1.2,   Name "Tubería/5Razón de crecimiento"},
  Ldes    = {10,    Name "Tubería/6Tramo tras la entrada (D)"},
  nq      = {10,    Name "Tubería/7Celdas por cuarto"},
  dz      = {0.25,  Name "Tubería/8Celda axial Δz (D)"}
];

// ------------------------------------------------ geometría de la sección (proporciones del 3.1.1)
R  = D / 2;
rm = 0.8 * R;          // círculo intermedio: el anillo de la capa límite ocupa el 20 % exterior del radio
a  = 0.4 * R;          // semilado del cuadro central

// ------------------------------------------------ factor de fricción y velocidad de fricción
// Laminar: Hagen-Poiseuille. Turbulento (tubo liso): Petukhov, válido de 3000 a 5·10^6.
If (regimen == 0)
  f = 64 / Re;
Else
  f = 1 / (0.790 * Log(Re) - 1.64)^2;
EndIf
// u_tau / U = Sqrt(f/8); en longitudes: nu / u_tau = D / (Re Sqrt(f/8))
lv = D / (Re * Sqrt(f / 8));          // longitud viscosa nu/u_tau (m)

// y+ mide la distancia del CENTRO de la primera celda a la pared: la altura es el doble.
h1 = 2 * yplus * lv;

// ------------------------------------------------ longitud: entrada más tramo desarrollado
If (regimen == 0)
  Le = D * (0.619^1.6 + (0.0567 * Re)^1.6)^(1 / 1.6);   // Durst et al. (2005)
Else
  Le = D * 4.4 * Re^(1 / 6);                              // White, Fluid Mechanics
EndIf
L = Le + Ldes * D;

// ------------------------------------------------ nodos de la sección
hs  = 2 * a / nq;                        // lado de las celdas del cuadro central
nr  = Round((rm - a) / hs);              // celdas de la banda, del cuadro al círculo intermedio

// El anillo va de h1 en la pared hacia el círculo intermedio, creciendo a lo más gmax por celda. La suma de la
// progresión, h1 (g^n − 1)/(g − 1) = t, da el número de celdas n; se redondea hacia arriba y la macro Razon (la del
// 2.2.2) busca por bisección la razón exacta que llena el anillo con esas n celdas.
Macro Razon
  rA = 1.0 + 1.e-9;  rB = 3.0;
  For iter In {1:80}
    rM = 0.5 * (rA + rB);
    sM = eh1 * (rM^(eN - 1) - 1.0) / (rM - 1.0);
    If (sM < eL)
      rA = rM;
    Else
      rB = rM;
    EndIf
  EndFor
  eR = 0.5 * (rA + rB);
Return

eL = R - rm;  eh1 = h1;
eN = 1 + Ceil(Log(1 + eL * (gmax - 1) / h1) / Log(gmax));
Call Razon;
nb = eN;  g = eR;                        // nodos del anillo y razón de crecimiento desde la pared
hN = h1 * g^(nb - 2);                    // la celda del anillo junto al círculo intermedio
hb = (rm - a) / nr;                      // la celda de la banda, a media altura del cuadro

nz = Round(L / (dz * D));                // capas a lo largo del eje
N3 = (nq^2 + 4 * nq * nr + 4 * nq * (nb - 1)) * nz;

Printf("Re = %g   f = %g   nu/u_tau = %g m", Re, f, lv);
Printf("y+ = %g  ->  primera celda h1 = %g m (%g D)", yplus, h1, h1 / D);
Printf("anillo: %g celdas con razón %g, de %g m a %g m (la banda sigue con %g m)", nb - 1, g, h1, hN, hb);
Printf("longitud de entrada Le = %g D; tubería L = %g D en %g capas", Le / D, L / D, nz);
Printf("celdas previstas: %g", N3);

// ------------------------------------------------ puntos, curvas y superficies (como el 3.1.1)
Point(1)  = {0, 0, 0};
Point(2)  = {a, a, 0};   Point(3) = {-a, a, 0};   Point(4) = {-a, -a, 0};   Point(5) = {a, -a, 0};
Point(6)  = {rm*Cos(Pi/4), rm*Sin(Pi/4), 0};    Point(7)  = {-rm*Cos(Pi/4), rm*Sin(Pi/4), 0};
Point(8)  = {-rm*Cos(Pi/4), -rm*Sin(Pi/4), 0};  Point(9)  = {rm*Cos(Pi/4), -rm*Sin(Pi/4), 0};
Point(10) = {R*Cos(Pi/4), R*Sin(Pi/4), 0};      Point(11) = {-R*Cos(Pi/4), R*Sin(Pi/4), 0};
Point(12) = {-R*Cos(Pi/4), -R*Sin(Pi/4), 0};    Point(13) = {R*Cos(Pi/4), -R*Sin(Pi/4), 0};

Line(1) = {2, 3};  Line(2) = {3, 4};  Line(3) = {4, 5};  Line(4) = {5, 2};          // cuadro central
Line(5) = {2, 6};  Line(6) = {3, 7};  Line(7) = {4, 8};  Line(8) = {5, 9};          // cuadro → círculo intermedio
Line(9) = {6, 10}; Line(10) = {7, 11}; Line(11) = {8, 12}; Line(12) = {9, 13};      // círculo intermedio → pared
Circle(13) = {6, 1, 7};   Circle(14) = {7, 1, 8};   Circle(15) = {8, 1, 9};   Circle(16) = {9, 1, 6};
Circle(17) = {10, 1, 11}; Circle(18) = {11, 1, 12}; Circle(19) = {12, 1, 13}; Circle(20) = {13, 1, 10};

Curve Loop(1) = {1, 2, 3, 4};         Plane Surface(1) = {1};
Curve Loop(2) = {1, 6, -13, -5};      Plane Surface(2) = {2};
Curve Loop(3) = {2, 7, -14, -6};      Plane Surface(3) = {3};
Curve Loop(4) = {3, 8, -15, -7};      Plane Surface(4) = {4};
Curve Loop(5) = {4, 5, -16, -8};      Plane Surface(5) = {5};
Curve Loop(6) = {13, 10, -17, -9};    Plane Surface(6) = {6};
Curve Loop(7) = {14, 11, -18, -10};   Plane Surface(7) = {7};
Curve Loop(8) = {15, 12, -19, -11};   Plane Surface(8) = {8};
Curve Loop(9) = {16, 9, -20, -12};    Plane Surface(9) = {9};

// ------------------------------------------------ malla: todos los números salen de los parámetros
Transfinite Curve {1:4, 13:20} = nq + 1;
Transfinite Curve {5:8} = nr + 1;
Transfinite Curve {9:12} = nb Using Progression 1 / g;   // las líneas van hacia la pared: cada celda 1/g de la anterior
Transfinite Surface {1:9};
Recombine Surface {1:9};

ext[] = Extrude {0, 0, L} { Surface{1:9}; Layers{nz}; Recombine; };
Physical Surface("inlet")  = {1:9};
Physical Surface("outlet") = {ext[0], ext[6], ext[12], ext[18], ext[24], ext[30], ext[36], ext[42], ext[48]};
Physical Surface("walls")  = {ext[34], ext[40], ext[46], ext[52]};
Physical Volume("fluid")   = {ext[1], ext[7], ext[13], ext[19], ext[25], ext[31], ext[37], ext[43], ext[49]};
Mesh.MshFileVersion = 2.2;
