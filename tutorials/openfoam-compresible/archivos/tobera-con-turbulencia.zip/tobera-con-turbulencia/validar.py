#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mide una corrida de la tobera con turbulencia (Tutorial 1.4). Se corre dentro de la carpeta del caso, después de ./Allrun:

    python3 validar.py

Lee los campos promediados de postProcessing/ejeMedio, secciones y paredes. Con RANS ubica la separación donde el esfuerzo
cortante de la pared cambia de signo y compara la presión de separación con los criterios de Summerfield y de Schmucker.
Sólo usa la biblioteca estándar: el Python de blueCFD no trae numpy.
"""
import glob
import math
import os
import sys

G = 1.4
R = 1 / G                 # a0² = γ R T0 = 1
HT = 0.2                  # semialtura de la garganta
ESPESOR = 0.1             # espesor de la malla en z
XG = 2.0                  # garganta
XE = 6.0                  # plano de salida
SECCIONES = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 5.99]


def leer(patron):
    """La tabla del último tiempo de postProcessing."""
    rutas = glob.glob(patron)
    if not rutas:
        sys.exit("No se encuentra %s: ¿terminó ./Allrun?" % patron)
    ruta = max(rutas, key=lambda r: float(os.path.basename(os.path.dirname(r))))
    with open(ruta) as f:
        return [[float(c) for c in r.split()] for r in f if r.strip() and not r.startswith("#")]


def mach(fila):
    """Mach de un renglón (posición, p, T, Ux, Uy, Uz): a = √T, porque γR = 1."""
    return math.hypot(fila[3], fila[4]) / math.sqrt(fila[2])


def integral(xs, ys):
    return sum(0.5 * (ys[i] + ys[i + 1]) * (xs[i + 1] - xs[i]) for i in range(len(xs) - 1))


def seccion(k):
    return leer("postProcessing/secciones/*/s%02d.xy" % k)


def gasto_bloqueado():
    return G * (2 / (G + 1)) ** ((G + 1) / (2 * (G - 1))) * HT * ESPESOR


def gasto(filas):
    """Gasto de la media tobera en una sección, y la parte que va hacia atrás."""
    ys = [f[0] for f in filas]
    w = [f[1] / (R * f[2]) * f[3] for f in filas]
    return integral(ys, w) * ESPESOR, integral(ys, [min(v, 0) for v in w]) * ESPESOR


def empuje(filas, pb):
    """Coeficiente de empuje: la cantidad de movimiento y la presión de la sección de salida entre p0 At."""
    ys = [f[0] for f in filas]
    v = [f[1] / (R * f[2]) * f[3] ** 2 + f[1] - pb for f in filas]
    return integral(ys, v) / HT


def mach_de_presion(p):
    """Mach isentrópico con presión total 1."""
    return math.sqrt(5 * (p ** (-2 / 7) - 1))


def pared():
    """x, p, componente x del esfuerzo cortante e y+ de las caras de la pared, ordenadas por x."""
    filas = sorted(leer("postProcessing/paredes/*/pared.xy"))
    return [(f[0], f[3], f[4] if len(f) > 5 else 0.0, f[7] if len(f) > 7 else 0.0) for f in filas]


def tramos_separados(w):
    """Tramos del divergente con flujo de retorno: el esfuerzo con el signo contrario al del convergente, que no se separa."""
    conv = sorted(f[2] for f in w if 0.5 < f[0] < XG)
    signo = math.copysign(1, conv[len(conv) // 2])
    tramos, actual = [], []
    for f in w:
        if f[0] > XG and f[2] * signo < 0:
            actual.append(f[0])
        else:
            if len(actual) >= 3:
                tramos.append((actual[0], actual[-1]))
            actual = []
    if len(actual) >= 3:
        tramos.append((actual[0], actual[-1]))
    return tramos


def principal():
    with open("parametros") as f:
        modelo, pb = f.read().split()[:2]
    pb = float(pb)
    print("Modelo %s, pb/p0 = %g\n" % (modelo, pb))

    eje = leer("postProcessing/ejeMedio/*/*.xy")
    ms = [(f[0], mach(f)) for f in eje if f[0] < XE]
    mmax = max(ms, key=lambda r: r[1])
    print("En el eje, dentro de la tobera")
    print("  Mach máximo                      %.3f en x = %.3f m" % (mmax[1], mmax[0]))
    sub = next((x for x, m in ms if x > mmax[0] and m < 1), None)
    if sub is None:
        print("  El eje sigue supersónico hasta la salida; Mach en x = 5.99 m: %.3f" % ms[-1][1])
    else:
        print("  El eje pasa a subsónico en        x = %.3f m" % sub)

    s0, s1 = seccion(0), seccion(len(SECCIONES) - 1)
    print("\nGasto y empuje")
    print("  Gasto en x = 0.5 m entre el bloqueado   %.4f" % (gasto(s0)[0] / gasto_bloqueado()))
    total, atras = gasto(s1)
    print("  Gasto de retorno en x = 5.99 m entre el total  %.4f" % (-atras / total))
    print("  Coeficiente de empuje F/(p0 At)   %.4f" % empuje(s1, pb))
    ma = [mach(f) for f in s1]
    print("  Mach en x = 5.99 m               de %.3f a %.3f" % (min(ma), max(ma)))

    w = pared()
    div = [f for f in w if XG < f[0] < XE]
    i = min(div, key=lambda f: f[1])
    print("\nPared del divergente")
    print("  Presión mínima p_i/p0            %.4f en x = %.3f m" % (i[1], i[0]))
    print("  p_i/pb                           %.3f" % (i[1] / pb))
    if modelo != "rans":
        return
    print("  y+ en la garganta                %.1f" % min(w, key=lambda f: abs(f[0] - XG))[3])
    print("  y+ en el divergente              de %.1f a %.1f" % (min(f[3] for f in div), max(f[3] for f in div)))
    tramos = tramos_separados(w)
    if not tramos:
        print("  La capa límite no se separa")
        pl = min(div, key=lambda f: abs(f[0] - 5.9))[1]
        print("  Presión de la pared en x = 5.9 m entre pb  %.3f" % (pl / pb))
        return
    for a, b in tramos:
        print("  Separada de x = %.3f a x = %.3f m" % (a, b))
    xs = tramos[0][0]
    ps = next(f[1] for f in w if f[0] >= xs)
    mi = mach_de_presion(i[1])
    print("  Presión donde se separa p_s/p0   %.4f (p_s/pb = %.3f)" % (ps, ps / pb))
    meseta = [f[1] for f in div if xs + 0.3 < f[0] < 5.8]
    if meseta:
        print("  Presión media de la zona separada entre pb  %.3f" % (sum(meseta) / len(meseta) / pb))
    print("  Mach de la pared antes de la subida (isentrópico)  %.3f" % mi)
    print("  Criterios de p_i/pb: Summerfield 0.400; Schmucker %.3f; esta corrida %.3f"
          % ((1.88 * mi - 1) ** -0.64, i[1] / pb))


if __name__ == "__main__":
    principal()
