@echo off
rem Rampa de compresion y expansion en blueCFD-Core 2024 (OpenFOAM 12).
rem Uso, desde la terminal de blueCFD y en la carpeta del caso:  Allrun.bat 0.01
rem El numero es el tamano de celda d en metros (0.02, 0.01 o 0.005); si se omite, 0.01.
rem Hace lo mismo que la receta de la guia: malla con Gmsh, gmshToFoam, tipos de parche,
rem checkMesh y foamRun. Gmsh tiene que estar en el PATH.
setlocal
set D=%1
if "%D%"=="" set D=0.01
cd /d %~dp0

where gmsh > nul 2>&1 || (echo No se encuentra gmsh: agregue su carpeta al PATH, por ejemplo& echo     set PATH=%%PATH%%;C:\gmsh-4.15.2-Windows64& exit /b 1)
call gmsh rampa.geo -setnumber d %D% -3 -o rampa.msh > log.gmsh 2>&1 || goto fallo
gmshToFoam rampa.msh > log.gmshToFoam 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/walls/type -set wall > log.foamDictionary 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/top/type -set symmetryPlane >> log.foamDictionary 2>&1 || goto fallo
foamDictionary constant/polyMesh/boundary -entry entry0/frontAndBack/type -set empty >> log.foamDictionary 2>&1 || goto fallo
checkMesh > log.checkMesh 2>&1 || goto fallo
foamRun > log.foamRun 2>&1 || goto fallo
echo Listo: d = %D% m. Promedios en postProcessing\region2 y postProcessing\region3.
goto :eof

:fallo
echo Fallo un paso: revisa el ultimo log.* de la carpeta del caso.
exit /b 1
