// Rampa de compresión y expansión para OpenFOAM (shockFluid), malla 2.5D estructurada
// Placa plana, rampa de ángulo th y meseta: un choque oblicuo en la primera esquina
// y un abanico de Prandtl-Meyer en la segunda. Unidades: metros.
// Se puede cambiar cualquier parámetro desde la terminal: gmsh rampa.geo -setnumber d 0.01 -3

DefineConstant[ th = 5 ];     // ángulo de la rampa (grados)
DefineConstant[ L1 = 1 ];     // placa plana antes de la rampa
DefineConstant[ Lr = 1 ];     // largo de la rampa, medido sobre su superficie
DefineConstant[ L3 = 1 ];     // meseta después de la segunda esquina
DefineConstant[ H = 1 ];      // altura del dominio sobre la placa
DefineConstant[ d = 0.01 ];   // tamaño de celda (cuadrada lejos de la rampa)
e = 0.01;                     // espesor de la extrusión (una sola celda)

t = th*Pi/180;
x2 = L1 + Lr*Cos(t);  y2 = Lr*Sin(t);   // segunda esquina
x3 = x2 + L3;

Point(1) = {0,  0,  0};
Point(2) = {L1, 0,  0};       // esquina de compresión
Point(3) = {x2, y2, 0};       // esquina de expansión
Point(4) = {x3, y2, 0};
Point(5) = {x3, H,  0};
Point(6) = {x2, H,  0};
Point(7) = {L1, H,  0};
Point(8) = {0,  H,  0};

Line(1) = {1, 2};  Line(2) = {2, 3};  Line(3) = {3, 4};    // pared
Line(4) = {4, 5};                                          // salida
Line(5) = {5, 6};  Line(6) = {6, 7};  Line(7) = {7, 8};    // techo
Line(8) = {8, 1};                                          // entrada
Line(9) = {2, 7};  Line(10) = {3, 6};                      // divisiones entre bloques

Curve Loop(1) = {1, 9, 7, 8};    Plane Surface(1) = {1};   // bloque de la placa
Curve Loop(2) = {2, 10, 6, -9};  Plane Surface(2) = {2};   // bloque de la rampa
Curve Loop(3) = {3, 4, 5, -10};  Plane Surface(3) = {3};   // bloque de la meseta

nx1 = Round(L1/d);  nx2 = Round((x2 - L1)/d);  nx3 = Round(L3/d);  ny = Round(H/d);
Transfinite Curve{1, 7} = nx1 + 1;
Transfinite Curve{2, 6} = nx2 + 1;
Transfinite Curve{3, 5} = nx3 + 1;
Transfinite Curve{8, 9, 10, 4} = ny + 1;
Transfinite Surface{1, 2, 3};
Recombine Surface{1, 2, 3};

ext[] = Extrude {0, 0, e} { Surface{1, 2, 3}; Layers{1}; Recombine; };
// ext[]: para cada superficie, [tapa, volumen, cara sobre la 1.ª curva, 2.ª, 3.ª, 4.ª]
Physical Surface("inlet")        = {ext[5]};
Physical Surface("outlet")       = {ext[15]};
Physical Surface("walls")        = {ext[2], ext[8], ext[14]};
Physical Surface("top")          = {ext[4], ext[10], ext[16]};
Physical Surface("frontAndBack") = {1, 2, 3, ext[0], ext[6], ext[12]};
Physical Volume("fluid")         = {ext[1], ext[7], ext[13]};

Mesh.MshFileVersion = 2.2;    // gmshToFoam lee el formato 2
