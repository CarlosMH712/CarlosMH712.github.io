#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Contorno del divergente por el método de características (Tutorial 1.5 de OpenFOAM · Flujo compresible).

    python3 moc.py [AR] [n]        # AR = Ae/At (5), n ondas del abanico de la garganta (200)

Es la tobera plana de longitud mínima (Anderson, Modern Compressible Flow, cap. 11): la garganta es una esquina de la pared,
el flujo en la línea sónica es uniforme (M = 1, θ = 0), y las n ondas de expansión que nacen en la esquina se cancelan al
llegar a la pared, de modo que la salida queda uniforme con el Mach de diseño. Escribe contorno_moc.geo (arreglos xMOC[] e
yMOC[], medidos desde la garganta), que tobera.geo lee con contorno = 1. Sólo usa la biblioteca estándar de Python: corre tal
cual en la terminal de blueCFD-Core.
"""
import math
import sys

G = 1.4
N_PUNTOS = 400            # puntos del contorno, a pasos iguales de longitud de arco


# ------------------------------------------------------------------------------------------------ flujo isentrópico
def biseccion(f, a, b, tol=1e-13):
    fa = f(a)
    for _ in range(300):
        m = 0.5 * (a + b)
        fm = f(m)
        if (fm > 0) == (fa > 0):
            a, fa = m, fm
        else:
            b = m
        if b - a < tol:
            break
    return 0.5 * (a + b)


def area(M):
    """A/A* de la tobera plana (el área es proporcional a la semialtura)."""
    return (2 / (G + 1) * (1 + 0.5 * (G - 1) * M * M)) ** ((G + 1) / (2 * (G - 1))) / M


def mach_supersonico(A):
    return biseccion(lambda M: area(M) - A, 1.0, 50.0)


def nu(M):
    """Función de Prandtl-Meyer, en radianes."""
    k = math.sqrt((G + 1) / (G - 1))
    return k * math.atan(math.sqrt(M * M - 1) / k) - math.atan(math.sqrt(M * M - 1))


def mach_de_nu(v):
    return biseccion(lambda M: nu(M) - v, 1.0 + 1e-12, 80.0)


# ------------------------------------------------------------------------------------------------ la red de características
def contorno(AR=5.0, n=200, He=1.0):
    """Los n + 1 puntos de la pared, de la esquina de la garganta a la salida, y la red P[(m, k)]: la onda k del abanico
    después de su m-ésima reflexión en el eje. En P(m, k), θ = θ_k − θ_m y ν = θ_k + θ_m."""
    Ht = He / AR
    th = [nu(mach_supersonico(AR)) / 2 * j / n for j in range(n + 1)]     # θ_j de cada onda; la pared gira θ_max = ν_e/2

    def ang(m, k, signo):
        """θ + μ (signo = +1, característica C+) o θ − μ (signo = −1, C−) en P(m, k)."""
        v = th[k] + th[m]
        mu = math.asin(1 / mach_de_nu(v)) if v > 1e-12 else math.pi / 2
        return (th[k] - th[m]) + signo * mu

    P = {(0, k): (0.0, Ht) for k in range(1, n + 1)}             # todas las ondas nacen en la esquina
    for m in range(1, n + 1):
        x0, y0 = P[(m - 1, m)]                                    # punto del eje: C− desde P(m−1, m) hasta y = 0
        s = math.tan(0.5 * (ang(m - 1, m, -1) + ang(m, m, -1)))
        P[(m, m)] = (x0 - y0 / s, 0.0)
        for k in range(m + 1, n + 1):
            xa, ya = P[(m, k - 1)]                                # C+ desde el punto anterior
            xb, yb = P[(m - 1, k)]                                # C− desde la reflexión anterior de la onda k
            sp = math.tan(0.5 * (ang(m, k - 1, +1) + ang(m, k, +1)))
            sm = math.tan(0.5 * (ang(m - 1, k, -1) + ang(m, k, -1)))
            x = (yb - ya + sp * xa - sm * xb) / (sp - sm)
            P[(m, k)] = (x, ya + sp * (x - xa))
    W = [(0.0, Ht)]                                               # la pared: cada C+ de P(m, n) la alcanza
    for m in range(1, n + 1):
        xc, yc = P[(m, n)]
        mu = math.asin(1 / mach_de_nu(th[n] + th[m]))
        sp = math.tan((th[n] - th[m]) + mu)
        sw = math.tan(0.5 * ((th[n] - th[m - 1]) + (th[n] - th[m])))     # la pared gira lo que gira el flujo
        xw0, yw0 = W[-1]
        x = (yw0 - yc + sp * xc - sw * xw0) / (sp - sw)
        W.append((x, yw0 + sw * (x - xw0)))
    return W, Ht, P


# ------------------------------------------------------------------------------------------------ remuestreo
def pchip(s, f):
    """Interpolación cúbica monótona (Fritsch y Carlson): sigue los puntos sin oscilar entre ellos."""
    h = [b - a for a, b in zip(s, s[1:])]
    d = [(f[i + 1] - f[i]) / h[i] for i in range(len(h))]
    m = [d[0]] + [0.0] * (len(s) - 2) + [d[-1]]
    for i in range(1, len(s) - 1):
        if d[i - 1] * d[i] > 0:
            w1, w2 = 2 * h[i] + h[i - 1], h[i] + 2 * h[i - 1]
            m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])

    def valor(x):
        i = min(max(0, next((j for j in range(len(h)) if x <= s[j + 1]), len(h) - 1)), len(h) - 1)
        t = (x - s[i]) / h[i]
        h00, h10 = (1 + 2 * t) * (1 - t) ** 2, t * (1 - t) ** 2
        h01, h11 = t * t * (3 - 2 * t), t * t * (t - 1)
        return h00 * f[i] + h10 * h[i] * m[i] + h01 * f[i + 1] + h11 * h[i] * m[i + 1]
    return valor


def principal():
    AR = float(sys.argv[1]) if len(sys.argv) > 1 else 5.0
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    W, Ht, _ = contorno(AR, n)
    Me = mach_supersonico(AR)
    print("AR = %g: Mach de diseño %.4f, ν_e = %.2f°; la pared sale de la garganta a %.2f°" % (
        AR, Me, math.degrees(nu(Me)), math.degrees(nu(Me) / 2)))
    print("%d ondas: la pared llega a x = %.4f con y = %.4f (He = 1: %+.3f %%)" % (n, W[-1][0], W[-1][1], 100 * (W[-1][1] - 1)))
    # a pasos iguales de longitud de arco, porque Transfinite reparte los nodos según la parametrización de la Spline
    s = [0.0]
    for (a, b), (c, d) in zip(W, W[1:]):
        s.append(s[-1] + math.hypot(c - a, d - b))
    fx, fy = pchip(s, [w[0] for w in W]), pchip(s, [w[1] for w in W])
    si = [s[-1] * i / N_PUNTOS for i in range(N_PUNTOS + 1)]
    xs, ys = [fx(v) for v in si], [fy(v) for v in si]
    # la discretización deja la salida unas centésimas por ciento corta: un ajuste en y la deja exacta (Ht = He/AR, He = 1)
    esc = (1.0 - Ht) / (ys[-1] - ys[0])
    ys = [Ht + (y - ys[0]) * esc for y in ys]
    print("Divergente de %.4f m; ajuste en y %.5f; pendiente de la pared en la salida %.2f°" % (
        xs[-1], esc, math.degrees(math.atan2(ys[-1] - ys[-2], xs[-1] - xs[-2]))))
    with open("contorno_moc.geo", "w") as f:
        f.write("// Divergente de método de características de la tobera de longitud mínima (AR = %g, n = %d ondas), de moc.py.\n"
                % (AR, n))
        f.write("// Puntos a pasos iguales de longitud de arco; x medida desde la garganta.\n")
        f.write("xMOC[] = {%s};\n" % ", ".join("%.8f" % v for v in xs))
        f.write("yMOC[] = {%s};\n" % ", ".join("%.8f" % v for v in ys))
    print("Escrito contorno_moc.geo. Siguiente paso: ./Allrun moc PB")


if __name__ == "__main__":
    principal()
