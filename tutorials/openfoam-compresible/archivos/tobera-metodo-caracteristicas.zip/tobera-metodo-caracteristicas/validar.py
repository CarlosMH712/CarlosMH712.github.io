#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mide la sección de salida y las ondas del labio y las compara con la teoría (Tutorial 1.5 de OpenFOAM · Flujo compresible).

    python3 validar.py

Lee el caso de `parametros` (lo escribe el Allrun: el contorno, pb y la posición de la salida) y los muestreos del último
tiempo en postProcessing/ondas (la sección de salida y sesenta rectas verticales cada 0.05 m a partir de ella) y
postProcessing/ejeMedio. Sólo usa la biblioteca estándar de Python: corre tal cual en la terminal de blueCFD-Core.

El gas es el normalizado de la serie: p0 = T0 = 1 y a0 = 1, con γ = 1.4. La teoría de las ondas del labio usa el estado que
promete el diseño: el Mach de la razón de áreas, la presión de diseño y el flujo paralelo al eje. Es lo que el contorno de
método de características busca entregar; el cosenoidal no lo entrega, y la diferencia es lo que mide esta comparación.

    pb mayor que la presión junto al labio: un choque oblicuo sale del labio. En cada recta su posición es el centroide del
    gradiente de p, y β sale de una recta ajustada a esas posiciones.
    pb menor: un abanico de Prandtl-Meyer. Su cabeza es donde p empieza a caer de la meseta.
    Salida subsónica en el eje: el choque normal entró a la tobera; se compara su posición con la cuasi-1D.
"""
import glob
import math
import os
import re

G = 1.4
R = 1 / G                 # a0² = γ R T0 = 1
AR, HE, LC, LD_COS = 5.0, 1.0, 2.0, 4.0
HT = HE / AR


# ------------------------------------------------------------------------------------------------ la teoría
def biseccion(f, a, b, tol=1e-12):
    fa = f(a)
    for _ in range(200):
        m = 0.5 * (a + b)
        fm = f(m)
        if (fm > 0) == (fa > 0):
            a, fa = m, fm
        else:
            b = m
        if b - a < tol:
            break
    return 0.5 * (a + b)


def area(M):
    return (2 / (G + 1) * (1 + 0.5 * (G - 1) * M * M)) ** ((G + 1) / (2 * (G - 1))) / M


def mach_de_area(A, supersonico):
    return biseccion(lambda M: area(M) - A, 1.0, 50.0) if supersonico else biseccion(lambda M: area(M) - A, 1e-6, 1.0)


def p_p0(M):
    return (1 + 0.5 * (G - 1) * M * M) ** (-G / (G - 1))


def nu(M):
    """Función de Prandtl-Meyer, en radianes."""
    k = math.sqrt((G + 1) / (G - 1))
    return k * math.atan(math.sqrt(M * M - 1) / k) - math.atan(math.sqrt(M * M - 1))


def choque_oblicuo(M1, r):
    """β y θ del choque que sube la presión r veces; None si no puede estar adherido."""
    Mn1 = math.sqrt(1 + (G + 1) / (2 * G) * (r - 1))
    if Mn1 >= M1:
        return None
    b = math.asin(Mn1 / M1)
    th = math.atan(2 / math.tan(b) * (M1 ** 2 * math.sin(b) ** 2 - 1) / (M1 ** 2 * (G + math.cos(2 * b)) + 2))
    return b, th


def choque_normal_pb(A_s):
    """pb/p0 que pone el choque normal donde A/At = A_s (cuasi-1D): p0 cae a r p0 y la salida es subsónica."""
    M1 = mach_de_area(A_s, True)
    r = ((G + 1) * M1 ** 2 / ((G - 1) * M1 ** 2 + 2)) ** (G / (G - 1)) * ((G + 1) / (2 * G * M1 ** 2 - (G - 1))) ** (1 / (G - 1))
    return r * p_p0(mach_de_area(AR * r, False))


ME = mach_de_area(AR, True)          # el Mach de diseño
PE = p_p0(ME)                        # y su presión: la de diseño


# ------------------------------------------------------------------------------------------------ el contorno
def pared(contorno):
    """Puntos (x, y) de la pared del divergente, de la garganta a la salida."""
    if contorno == "coseno":
        return [(LC + LD_COS * i / 400, 0.2 + 0.4 * (1 - math.cos(math.pi * i / 400))) for i in range(401)]
    t = open("contorno_moc.geo").read()
    xs = [float(v) for v in re.search(r"xMOC\[\] = \{(.*?)\}", t).group(1).split(",")]
    ys = [float(v) for v in re.search(r"yMOC\[\] = \{(.*?)\}", t).group(1).split(",")]
    return [(LC + x, y) for x, y in zip(xs, ys)]


def x_de_area(puntos, A):
    """Dónde la semialtura vale A·Ht (la pared crece de la garganta a la salida)."""
    for (x0, y0), (x1, y1) in zip(puntos, puntos[1:]):
        if y0 <= A * HT <= y1:
            return x0 + (x1 - x0) * (A * HT - y0) / (y1 - y0)
    return None


# ------------------------------------------------------------------------------------------------ la corrida
def leer(patron):
    """Las columnas del archivo del último tiempo que coincide con el patrón."""
    rutas = glob.glob(patron)
    if not rutas:
        raise SystemExit("No hay %s: ¿terminó el Allrun?" % patron)
    ruta = max(rutas, key=lambda r: float(os.path.basename(os.path.dirname(r))))
    filas = [[float(v) for v in l.split()] for l in open(ruta) if l.strip() and not l.startswith("#")]
    return [list(c) for c in zip(*filas)]


def recta(nombre):
    """Una recta vertical: y, p, T, Ux, Uy, y de ahí el Mach y el ángulo del flujo."""
    y, p, T, ux, uy = leer("postProcessing/ondas/*/%s.xy" % nombre)[:5]
    M = [math.hypot(a, b) / math.sqrt(t) for a, b, t in zip(ux, uy, T)]
    ang = [math.degrees(math.atan2(b, a)) for a, b in zip(ux, uy)]
    return {"y": y, "p": p, "T": T, "ux": ux, "M": M, "ang": ang}


def en(q, y0):
    """Los valores de una recta a la altura y0."""
    i = min(range(len(q["y"])), key=lambda j: abs(q["y"][j] - y0))
    return {k: v[i] for k, v in q.items()}


def con_gasto(s, valores):
    """Promedio ponderado con el gasto ρ Ux de la sección (regla del trapecio en y)."""
    w = [p / (R * t) * u for p, t, u in zip(s["p"], s["T"], s["ux"])]
    num = sum(0.5 * (w[i] * valores[i] + w[i + 1] * valores[i + 1]) * (s["y"][i + 1] - s["y"][i]) for i in range(len(w) - 1))
    den = sum(0.5 * (w[i] + w[i + 1]) * (s["y"][i + 1] - s["y"][i]) for i in range(len(w) - 1))
    return num / den


def ajuste(xs, ys, desde, hasta):
    """Pendiente de la recta de mínimos cuadrados en el tramo, y su desviación."""
    par = [(x, y) for x, y in zip(xs, ys) if desde <= x <= hasta and y == y]
    n = len(par)
    mx, my = sum(p[0] for p in par) / n, sum(p[1] for p in par) / n
    m = sum((x - mx) * (y - my) for x, y in par) / sum((x - mx) ** 2 for x, _ in par)
    rms = math.sqrt(sum((y - my - m * (x - mx)) ** 2 for x, y in par) / n)
    return m, rms


def choque(lineas):
    """Posición del choque en cada recta: el centroide del gradiente de p."""
    pos = []
    for _, q in lineas:
        i_ok = [j for j, y in enumerate(q["y"]) if 0.05 < y < 1.4]
        y = [q["y"][j] for j in i_ok]
        p = [q["p"][j] for j in i_ok]
        g = [(p[j + 1] - p[j - 1]) / (y[j + 1] - y[j - 1]) for j in range(1, len(y) - 1)]
        y = y[1:-1]
        k = max(range(len(g)), key=lambda j: g[j])
        par = [(yy, gg) for yy, gg in zip(y, g) if abs(yy - y[k]) < 0.1 and gg > 0]
        pos.append(sum(a * b for a, b in par) / sum(b for _, b in par) if par else float("nan"))
    return pos


def fin_del_ajuste(xs, pos, xe):
    """Hasta dónde llega el tramo recto: con disco de Mach, el centroide salta al disco en el punto triple."""
    k0 = min(range(len(xs)), key=lambda k: abs(xs[k] - (xe + 0.1)))
    for k in range(k0, len(xs) - 1):
        if not abs(pos[k + 1] - pos[k]) <= 0.1:
            return min(xs[k], xe + 0.9)
    return xe + 0.9


def cabeza_del_abanico(lineas, pb):
    """Dónde p empieza a caer de la meseta, en cada recta."""
    cabeza = []
    for _, q in lineas:
        idx = [j for j, y in enumerate(q["y"]) if 0.05 < y < 2.5]
        y = [q["y"][j] for j in idx]
        p = [q["p"][j] for j in idx]
        T = [q["T"][j] for j in idx]
        yb = next((a for a, t in zip(y, T) if t > 0.6), y[-1])    # el borde del chorro: el ambiente está a T0 = 1
        dentro = [a < yb - 0.02 for a in y]
        ipk = max((j for j in range(len(y)) if dentro[j] and y[j] > 0.3), key=lambda j: p[j], default=None)
        if ipk is None:
            cabeza.append(float("nan")); continue
        tope = p[ipk]
        j = next((j for j in range(len(y)) if y[j] > y[ipk] and dentro[j] and p[j] < pb + 0.03 * (tope - pb)), None)
        k = [i for i in range(len(y)) if j is not None and 0.3 < y[i] < y[j] and p[i] >= tope - 0.03 * (tope - pb)]
        cabeza.append(y[k[-1]] if k else float("nan"))
    return cabeza


def eje():
    x, _, T, ux, uy = leer("postProcessing/ejeMedio/*/eje.xy")[:5]
    return x, [math.hypot(a, b) / math.sqrt(t) for a, b, t in zip(ux, uy, T)]


def renglon(nombre, of, teoria, grados=True):
    if grados:
        print("  %-38s %8.1f° %8.1f° %+7.1f°" % (nombre, of, teoria, of - teoria))
    else:
        print("  %-38s %9.4f %9.4f %+6.2f %%" % (nombre, of, teoria, 100 * (of / teoria - 1)))


def principal():
    if not os.path.exists("parametros"):
        raise SystemExit("No hay archivo parametros: corra primero el Allrun")
    contorno, pb, xe = open("parametros").read().split()
    pb, xe = float(pb), float(xe)
    print("Tobera %s, salida en x = %.3f m; ambiente a pb = %g (pb/p_diseño = %.3g)" % (
        "de método de características" if contorno == "moc" else "cosenoidal", xe, pb, pb / PE))

    s = recta("salida")
    p0 = [p * (1 + 0.2 * m * m) ** 3.5 for p, m in zip(s["p"], s["M"])]
    labio, centro = en(s, 0.95), en(s, 0.005)
    print()
    print("Sección de salida, x = %.3f m" % (xe - 0.01))
    if centro["M"] < 1:
        xs, M = eje()
        i_max = max((i for i in range(len(xs)) if LC < xs[i] < xe), key=lambda i: M[i])    # el flujo más rápido, delante del choque
        x_sub = next(xs[i] for i in range(i_max, len(xs)) if M[i] < 1)
        A_s = biseccion(lambda A: choque_normal_pb(A) - pb, 1.0001, AR)
        x_q1d = x_de_area(pared(contorno), A_s)
        print("  El eje es subsónico: el choque normal entró a la tobera.")
        print("  %-38s %9s %9s %8s" % ("", "OpenFOAM", "cuasi-1D", "dif."))
        print("  %-38s %9.3f %9.3f %+7.3f m" % ("x del choque en el eje (Mach medio = 1)", x_sub, x_q1d, x_sub - x_q1d))
        print("  (la cuasi-1D lo pone donde A/At = %.3f)" % A_s)
        print("  %-38s %9.4f" % ("presión total media en la salida", con_gasto(s, p0)))
        return
    print("  %-38s %9s %9s %8s" % ("", "OpenFOAM", "diseño", "dif."))
    renglon("Mach medio (con el gasto)", con_gasto(s, s["M"]), ME, False)
    nucleo = [i for i, y in enumerate(s["y"]) if y <= 0.95]
    for nombre, v, d in (("Mach", s["M"], 3), ("presión p/p0", s["p"], 4)):
        print("  %-38s %9s    de %.*f a %.*f" % (nombre + ", de y = 0 a 0.95", "", d, min(v[i] for i in nucleo),
                                                 d, max(v[i] for i in nucleo)))
    print("  %-38s %9s    hasta %.2f°" % ("ángulo del flujo, de y = 0 a 0.95", "", max(abs(s["ang"][i]) for i in nucleo)))
    renglon("presión total media (con el gasto)", con_gasto(s, p0), 1.0, False)
    sin = [i for i, y in enumerate(s["y"]) if y <= 0.97]
    sub = {k: [v[i] for i in sin] for k, v in s.items()}
    print("  (junto a la pared, de y = 0.97 a 1, la presión total cae de %.2f a %.2f: es la capa numérica de la" % (
        p0[sin[-1]], p0[-1]))
    print("   pared de deslizamiento; sin ella, la presión total media de la sección es %.4f)" % con_gasto(sub, [p0[i] for i in sin]))

    print()
    print("Ondas del labio")
    print("  junto al labio (y = 0.95): p = %.4f, M = %.3f, %.1f° hacia arriba" % (labio["p"], labio["M"], labio["ang"]))
    print("  la teoría usa el estado de diseño: M = %.4f, p = %.6f, flujo paralelo al eje" % (ME, PE))
    lineas = [(xe + 0.05 * (k + 1), recta("x%03d" % k)) for k in range(60)]
    xs = [x for x, _ in lineas]
    print()
    if abs(pb / PE - 1) < 0.05:
        print("  pb es la presión de diseño: la teoría no pone onda en el labio. Lo que se ve ahí")
        print("  responde a la diferencia entre pb y la presión junto al labio, %+.0f %%." % (100 * (labio["p"] / pb - 1)))
        return
    print("  %-38s %9s %9s %8s" % ("", "OpenFOAM", "teoría", "dif."))
    if pb > labio["p"]:
        pos = choque(lineas)
        fin = fin_del_ajuste(xs, pos, xe)
        m, rms = ajuste(xs, pos, xe + 0.1, fin)
        t = choque_oblicuo(ME, pb / PE) if pb > PE else None
        if t is None:
            print("  %-38s %8.1f°" % ("β del choque, con el eje", -math.degrees(math.atan(m))))
            print("  La teoría con el estado de diseño no da choque: pb no pasa de la presión de diseño.")
        else:
            renglon("β del choque, con el eje", -math.degrees(math.atan(m)), math.degrees(t[0]))
        print("  (ajuste de x = %.2f a %.2f, desviación %.3f m)" % (xe + 0.1, fin, rms))
    else:
        cabeza = cabeza_del_abanico(lineas, pb)
        mc, rc = ajuste(xs, cabeza, xe + 0.15, xe + 0.8)
        if pb < PE:
            renglon("cabeza del abanico, con el eje", -math.degrees(math.atan(mc)), math.degrees(math.asin(1 / ME)))
        else:
            renglon("cabeza, con el estado junto al labio", -math.degrees(math.atan(mc)),
                    math.degrees(math.asin(1 / labio["M"])) - labio["ang"])
            print("  La teoría con el estado de diseño da un choque, pero junto al labio la presión es mayor que pb:")
            print("  en el labio hay un abanico. Es la salida no uniforme del contorno.")
        print("  (desviación del ajuste %.3f m)" % rc)


if __name__ == "__main__":
    principal()
