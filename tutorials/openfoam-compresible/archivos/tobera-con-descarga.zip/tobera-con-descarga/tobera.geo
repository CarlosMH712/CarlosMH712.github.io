// Media tobera convergente-divergente plana (Tutorial 1.2 de OpenFOAM · Flujo compresible: sin descarga; 1.3: con descarga).
// Sin descarga (chorro = 0) el dominio acaba en la salida de la tobera: dos bloques (convergente y divergente) del eje a la
// pared. Con descarga (chorro = 1) se agregan el núcleo del chorro y el ambiente sobre el labio. El eje es un plano de
// simetría y la malla tiene una sola capa en z, como pide OpenFOAM para 2D. Con chorro = 2 sólo se malla el chorro, con la
// entrada en el plano de salida de la tobera: sirve para estudiar las ondas del labio con un flujo de salida uniforme.
//   gmsh tobera.geo -3 -format msh22 -o tobera.msh
//   gmsh tobera.geo -3 -format msh22 -setnumber AR 4 -setnumber nR 40 -o tobera.msh

SetFactory("Built-in");

DefineConstant[
  AR  = {5,   Name "Tobera/1Razón de áreas Ae entre At"},
  He  = {1,   Name "Tobera/2Semialtura de salida He (m)"},
  Lc  = {2,   Name "Tobera/3Longitud del convergente (m)"},
  Ld  = {4,   Name "Tobera/4Longitud del divergente (m)"},
  nR  = {30,  Name "Malla/1Celdas en la semialtura de salida"},
  e   = {0.1, Name "Malla/2Espesor en z (m)"},
  chorro = {0, Choices{0 = "Sin descarga", 1 = "Con descarga", 2 = "Sólo el chorro (entrada uniforme en la salida)"}, Name "Chorro/1Dominio"},
  fDown  = {8,    Name "Chorro/2Longitud aguas abajo (diámetros de salida)"},
  fFar   = {6,    Name "Chorro/3Semialtura del dominio (He)"},
  hJ     = {0.05, Name "Chorro/4Celda del final del chorro (m)"},
  hA     = {0.25, Name "Chorro/5Celda del borde del ambiente (m)"},
  contorno = {0, Choices{0 = "Coseno", 1 = "Método de características (MOC)"}, Name "Tobera/5Contorno del divergente"}
];
If (contorno == 1)
  Include "contorno_moc.geo";            // xMOC[], yMOC[]: el divergente de longitud mínima, de moc.py
  Ld = xMOC[#xMOC[] - 1];                 // la longitud la da el contorno
EndIf

Ht = He / AR;            // semialtura de la garganta (en la plana el área es proporcional a la semialtura)
xt = Lc;                 // garganta
xe = Lc + Ld;            // salida

// Celdas cuadradas en la garganta y en la salida; la progresión empalma los dos tamaños.
hT = Ht / nR;  hE = He / nR;
Macro Empalme
  eR = (eL - eh1) / (eL - ehN);
  eN = 2 + Floor(Log(ehN / eh1) / Log(eR) + 0.5);
Return
eL = Lc;  eh1 = hT;  ehN = hE;               // convergente, de la garganta a la entrada
Call Empalme;
nC = eN;  rC = eR;
eL = Ld;  eh1 = hT;  ehN = hE;               // divergente, de la garganta a la salida
Call Empalme;
nD = eN;  rD = eR;
xo = xe + fDown * 2 * He;    // final del chorro
Hf = fFar * He;              // borde superior del ambiente
If (chorro >= 1)
  eL = xo - xe;  eh1 = hE;  ehN = hJ;           // chorro, de la salida al final del dominio
  Call Empalme;
  nJ = eN;  rJ = eR;
  eL = Hf - He;  eh1 = hE;  ehN = hA;           // ambiente, del labio hacia arriba
  Call Empalme;
  nA = eN;  rA = eR;
  Printf("chorro: %g nodos (razón %g); ambiente %g nodos (razón %g)", nJ, rJ, nA, rA);
EndIf
Printf("garganta Ht = %g m; convergente %g nodos (razón %g); divergente %g nodos (razón %g)", Ht, nC, rC, nD, rD);

Point(3) = {xe, 0, 0};   Point(6) = {xe, He, 0};
Line(7) = {3, 6};                                  // salida de la tobera
If (chorro < 2)
  Point(1) = {0,  0, 0};   Point(2) = {xt, 0, 0};                                      // eje
  Point(4) = {0, He, 0};   Point(5) = {xt, Ht, 0};                                     // pared

  // La pared: H = Ht + (He − Ht)(1 − cos πs)/2, con s de 0 en la garganta a 1 en la entrada o en la salida.
  // Doscientos puntos a pasos iguales en s: Transfinite sigue la parametrización de la Spline.
  nP = 200;
  For i In {1 : nP - 1}
    s = i / nP;
    Hs = Ht + (He - Ht) * 0.5 * (1 - Cos(Pi * s));
    Point(1000 + i) = {xt - Lc * s, Hs, 0};
    If (contorno == 0)
      Point(2000 + i) = {xt + Ld * s, Hs, 0};
    EndIf
  EndFor
  If (contorno == 1)
    nP2 = #xMOC[] - 1;
    For i In {1 : nP2 - 1}
      Point(2000 + i) = {xt + xMOC[i], yMOC[i], 0};
    EndFor
  EndIf
  Hide { Point{1001 : 1000 + nP - 1}; }
  If (contorno == 0)
    Hide { Point{2001 : 2000 + nP - 1}; }
  Else
    Hide { Point{2001 : 2000 + nP2 - 1}; }
  EndIf

  Line(1) = {2, 1};                                  // eje del convergente
  Line(2) = {2, 3};                                  // eje del divergente
  Spline(3) = {5, 1001 : 1000 + nP - 1, 4};          // pared del convergente
  If (contorno == 0)
    Spline(4) = {5, 2001 : 2000 + nP - 1, 6};        // pared del divergente
  Else
    Spline(4) = {5, 2001 : 2000 + nP2 - 1, 6};
  EndIf
  Line(5) = {1, 4};   Line(6) = {2, 5};                    // entrada, garganta
EndIf
If (chorro >= 1)
  Point(7) = {xo, 0, 0};   Point(8) = {xo, He, 0};   Point(9) = {xe, Hf, 0};   Point(10) = {xo, Hf, 0};
  Line(8) = {3, 7};                                           // eje del chorro
  Line(9) = {7, 8};                                           // final del núcleo
  Line(10) = {6, 8};                                          // borde del chorro, desde el labio
  Line(11) = {6, 9};   Line(12) = {8, 10};   Line(13) = {9, 10};   // ambiente
EndIf

Transfinite Curve {7} = nR + 1;
sup[] = {};
If (chorro < 2)
  Curve Loop(1) = {6, 3, -5, -1};   Plane Surface(1) = {1};    // convergente
  Curve Loop(2) = {2, 7, -4, -6};   Plane Surface(2) = {2};    // divergente
  Transfinite Curve {1, 3} = nC Using Progression rC;
  Transfinite Curve {2, 4} = nD Using Progression rD;
  Transfinite Curve {5, 6} = nR + 1;
  sup[] = {1, 2};
EndIf
If (chorro >= 1)
  Curve Loop(3) = {8, 9, -10, -7};     Plane Surface(3) = {3};       // núcleo del chorro
  Curve Loop(4) = {10, 12, -13, -11};  Plane Surface(4) = {4};       // ambiente
  Transfinite Curve {8, 10, 13} = nJ Using Progression rJ;
  Transfinite Curve {9} = nR + 1;
  Transfinite Curve {11, 12} = nA Using Progression rA;
  sup[] += {3, 4};
EndIf
Transfinite Surface {sup[]};
Recombine Surface {sup[]};
Mesh.Smoothing = 0;       // el suavizado mueve los nodos que Transfinite acaba de colocar

ext[] = Extrude {0, 0, e} { Surface{sup[]}; Layers{1}; Recombine; };

// Grupos físicos por posición, no por índice.
eps = 1e-6;
If (chorro == 0)
  xf = xe;  Hz = He;
Else
  xf = xo;  Hz = Hf;
EndIf
x0 = 0;                                  // plano de la entrada
If (chorro == 2)
  x0 = xe;
EndIf
entrada[] = Surface In BoundingBox {x0 - eps, -eps, -eps, x0 + eps, He + eps, e + eps};
salida[]  = Surface In BoundingBox {xf - eps, -eps, -eps, xf + eps, Hz + eps, e + eps};
eje[]     = Surface In BoundingBox {x0 - eps, -eps, -eps, xf + eps, eps, e + eps};
pared[]   = Surface In BoundingBox {-eps, Ht - eps, -eps, xe + eps, He + eps, e + eps};
frente[]  = Surface In BoundingBox {x0 - eps, -eps, -eps, xf + eps, Hz + eps, eps};
atras[]   = Surface In BoundingBox {x0 - eps, -eps, e - eps, xf + eps, Hz + eps, e + eps};
Physical Surface("inlet")        = {entrada[]};
Physical Surface("outlet")       = {salida[]};
Physical Surface("axis")         = {eje[]};
If (chorro < 2)
  Physical Surface("nozzleWall")   = {pared[]};
EndIf
Physical Surface("frontAndBack") = {frente[], atras[]};
If (chorro >= 1)
  // el labio (x = xe, de y = He a Hf) y el borde superior son la frontera con el ambiente
  labio[] = Surface In BoundingBox {xe - eps, He - eps, -eps, xe + eps, Hf + eps, e + eps};
  techo[] = Surface In BoundingBox {xe - eps, Hf - eps, -eps, xo + eps, Hf + eps, e + eps};
  Physical Surface("farField") = {labio[], techo[]};
EndIf
Physical Volume("fluid")         = Volume In BoundingBox {x0 - eps, -eps, -eps, xf + eps, Hz + eps, e + eps};

Printf("caras: entrada %g, salida %g, eje %g, pared %g, frente y atrás %g", #entrada[], #salida[], #eje[], #pared[], #frente[] + #atras[]);

Mesh.MshFileVersion = 2.2;   // gmshToFoam sólo lee MSH 2 ASCII
Mesh.Binary = 0;
