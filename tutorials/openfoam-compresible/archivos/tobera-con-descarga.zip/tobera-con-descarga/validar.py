#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mide las ondas del labio y las compara con la teoría (Tutorial 1.3 de OpenFOAM · Flujo compresible).

    python3 validar.py

Lee el caso de `parametros` (lo escribe el Allrun) y los muestreos del último tiempo en postProcessing/ondas (sesenta
rectas verticales cada 0.05 m desde x = 6.05 y la sección de salida) y postProcessing/ejeMedio. Sólo usa la biblioteca
estándar de Python: corre tal cual en la terminal de blueCFD-Core.

El gas es el normalizado de la rampa (Tutorial 1.1): T0 = 1 y a0 = 1, con γ = 1.4. Los ángulos se miden con el eje x y
con la dirección del flujo que llega al labio. En el chorro uniforme ese flujo es el de la entrada. En la tobera es el de
la sección de salida junto a la pared (x = 5.99, y = 0.97), tomado de la corrida de diseño del Tutorial 1.2: dentro de la
tobera el flujo no depende de pb, pero aquí la mancha numérica del choque del labio ya alcanza esa celda.

    pb > p1, sobreexpandida: un choque oblicuo sale del labio. En cada recta su posición es el centroide del gradiente
    de p (el máximo salta de celda en celda), y β sale de una recta ajustada a esas posiciones.
    pb < p1, subexpandida: un abanico de Prandtl-Meyer sale del labio. La cabeza es donde p empieza a caer de la meseta
    y la cola, donde llega a pb.
"""
import glob
import math
import os

G = 1.4
R = 1 / G                 # a0² = γ R T0 = 1
XE = 6.0                  # plano de salida
M_LABIO, P_LABIO, ANG_LABIO = 2.558, 0.0481, 1.34       # el flujo que llega al labio de la tobera (ver arriba)


# ------------------------------------------------------------------------------------------------ la teoría
def biseccion(f, a, b, tol=1e-12):
    fa = f(a)
    for _ in range(200):
        m = 0.5 * (a + b)
        fm = f(m)
        if (fm > 0) == (fa > 0):
            a, fa = m, fm
        else:
            b = m
        if b - a < tol:
            break
    return 0.5 * (a + b)


def nu(M):
    """Función de Prandtl-Meyer, en radianes."""
    k = math.sqrt((G + 1) / (G - 1))
    return k * math.atan(math.sqrt(M * M - 1) / k) - math.atan(math.sqrt(M * M - 1))


def choque_oblicuo(M1, r):
    """β, θ y Mach detrás del choque que sube la presión r veces; None si el choque no puede estar adherido."""
    Mn1 = math.sqrt(1 + (G + 1) / (2 * G) * (r - 1))
    if Mn1 >= M1:
        return None
    b = math.asin(Mn1 / M1)
    th = math.atan(2 / math.tan(b) * (M1 ** 2 * math.sin(b) ** 2 - 1) / (M1 ** 2 * (G + math.cos(2 * b)) + 2))
    Mn2 = math.sqrt((1 + 0.5 * (G - 1) * Mn1 ** 2) / (G * Mn1 ** 2 - 0.5 * (G - 1)))
    return b, th, Mn2 / math.sin(b - th)


def abanico(M1, r):
    """Mach detrás del abanico que baja la presión a r veces la que llega, con el giro y los ángulos de Mach."""
    M2 = math.sqrt(2 / (G - 1) * ((1 + 0.5 * (G - 1) * M1 ** 2) * r ** (-(G - 1) / G) - 1))
    return M2, nu(M2) - nu(M1), math.asin(1 / M1), math.asin(1 / M2)


# ------------------------------------------------------------------------------------------------ la corrida
def leer(patron):
    """Las columnas del archivo del último tiempo que coincide con el patrón."""
    rutas = glob.glob(patron)
    if not rutas:
        raise SystemExit("No hay %s: ¿terminó el Allrun?" % patron)
    ruta = max(rutas, key=lambda r: float(os.path.basename(os.path.dirname(r))))
    filas = [[float(v) for v in l.split()] for l in open(ruta) if l.strip() and not l.startswith("#")]
    return [list(c) for c in zip(*filas)]


def recta(nombre):
    """Una recta vertical: y, p, T, Ux, Uy, y de ahí el Mach y el ángulo del flujo."""
    y, p, T, ux, uy = leer("postProcessing/ondas/*/%s.xy" % nombre)[:5]
    M = [math.hypot(a, b) / math.sqrt(t) for a, b, t in zip(ux, uy, T)]
    ang = [math.degrees(math.atan2(b, a)) for a, b in zip(ux, uy)]
    return {"y": y, "p": p, "T": T, "M": M, "ang": ang}


def rectas():
    return [(XE + 0.05 * (k + 1), recta("x%03d" % k)) for k in range(60)]


def ajuste(xs, ys, desde, hasta):
    """Pendiente de la recta de mínimos cuadrados en el tramo, y su desviación."""
    par = [(x, y) for x, y in zip(xs, ys) if desde <= x <= hasta and y == y]
    n = len(par)
    mx, my = sum(p[0] for p in par) / n, sum(p[1] for p in par) / n
    m = sum((x - mx) * (y - my) for x, y in par) / sum((x - mx) ** 2 for x, _ in par)
    rms = math.sqrt(sum((y - my - m * (x - mx)) ** 2 for x, y in par) / n)
    return m, rms


def mediana(v):
    v = sorted(v)
    return v[len(v) // 2]


def detras(lineas, pos, hueco, hasta=XE + 1.0):
    """Ángulo, Mach y presión (medianas) a una distancia hueco por encima de la onda, en el primer metro o hasta donde se diga."""
    a, m, p = [], [], []
    for (x, q), yc in zip(lineas, pos):
        if XE + 0.1 <= x <= hasta and yc == yc:
            i = min(range(len(q["y"])), key=lambda j: abs(q["y"][j] - (yc + hueco)))
            a.append(q["ang"][i]); m.append(q["M"][i]); p.append(q["p"][i])
    return mediana(a), mediana(m), mediana(p)


def choque(lineas):
    """Posición del choque en cada recta: el centroide del gradiente de p."""
    pos = []
    for _, q in lineas:
        i_ok = [j for j, y in enumerate(q["y"]) if 0.05 < y < 1.4]
        y = [q["y"][j] for j in i_ok]
        p = [q["p"][j] for j in i_ok]
        g = [(p[j + 1] - p[j - 1]) / (y[j + 1] - y[j - 1]) for j in range(1, len(y) - 1)]
        y = y[1:-1]
        k = max(range(len(g)), key=lambda j: g[j])
        par = [(yy, gg) for yy, gg in zip(y, g) if abs(yy - y[k]) < 0.1 and gg > 0]
        pos.append(sum(a * b for a, b in par) / sum(b for _, b in par) if par else float("nan"))
    return pos


def fin_del_ajuste(xs, pos):
    """Hasta dónde llega el tramo recto: con disco de Mach, el centroide salta al disco en el punto triple."""
    k0 = min(range(len(xs)), key=lambda k: abs(xs[k] - (XE + 0.1)))
    for k in range(k0, len(xs) - 1):
        if not abs(pos[k + 1] - pos[k]) <= 0.1:
            return min(xs[k], XE + 0.9)
    return XE + 0.9


def abanico_medido(lineas, pb):
    """Posiciones de la cabeza y de la cola del abanico en cada recta."""
    cabeza, cola = [], []
    for _, q in lineas:
        idx = [j for j, y in enumerate(q["y"]) if 0.05 < y < 2.5]
        y = [q["y"][j] for j in idx]
        p = [q["p"][j] for j in idx]
        T = [q["T"][j] for j in idx]
        # borde del chorro: donde T supera 0.6 (el chorro está frío; el ambiente en reposo, a T0 = 1)
        yb = next((a for a, t in zip(y, T) if t > 0.6), y[-1])
        dentro = [a < yb - 0.02 for a in y]
        ipk = max((j for j in range(len(y)) if dentro[j] and y[j] > 0.3), key=lambda j: p[j], default=None)
        if ipk is None:
            cabeza.append(float("nan")); cola.append(float("nan")); continue
        tope = p[ipk]
        j = next((j for j in range(len(y)) if y[j] > y[ipk] and dentro[j] and p[j] < pb + 0.03 * (tope - pb)), None)
        if j is None:
            cabeza.append(float("nan")); cola.append(float("nan")); continue
        k = [i for i in range(len(y)) if 0.3 < y[i] < y[j] and p[i] >= tope - 0.03 * (tope - pb)]
        cola.append(y[j])
        cabeza.append(y[k[-1]] if k else float("nan"))
    return cabeza, cola


def renglon(nombre, of, teoria, grados=True):
    if grados:
        print("  %-36s %8.1f° %8.1f° %+7.1f°" % (nombre, of, teoria, of - teoria))
    else:
        print("  %-36s %9.3f %9.3f %+6.1f %%" % (nombre, of, teoria, 100 * (of / teoria - 1)))


def disco():
    """Dónde el Mach medio cae por debajo de 1 en el eje, en los dos metros que siguen a la salida (la primera reflexión)."""
    x, _, T, ux, uy = leer("postProcessing/ejeMedio/*/eje.xy")[:5]
    M = [math.hypot(a, b) / math.sqrt(t) for a, b, t in zip(ux, uy, T)]
    for xi, mi in zip(x, M):
        if XE < xi <= XE + 2 and mi < 1:
            return xi
    return None


def principal():
    if not os.path.exists("parametros"):
        raise SystemExit("No hay archivo parametros: corra primero el Allrun")
    d = open("parametros").read().split()
    lineas = rectas()
    xs = [x for x, _ in lineas]
    if d[0] == "uniforme":
        M1, p1, pb = float(d[1]), float(d[2]), float(d[3])
        ang1 = 0.0
        uniforme = True
        print("Chorro uniforme: M1 = %g, p1 = %g, pb = %g (pb/p1 = %.3g)" % (M1, p1, pb, pb / p1))
    else:
        pb = float(d[1])
        M1, p1, ang1 = M_LABIO, P_LABIO, ANG_LABIO
        uniforme = False
        s = recta("salida")
        print("Tobera con el ambiente a pb = %g" % pb)
        print("  sección de salida, en el eje:  p = %.4f, M = %.3f" % (s["p"][0], s["M"][0]))
        print("  junto al labio (del diseño):   p = %.4f, M = %.3f, %.1f° hacia arriba" % (p1, M1, ang1))
        print("  pb/p_labio = %.3g, pb/p_eje = %.3g" % (pb / p1, pb / s["p"][0]))
        if s["M"][0] < 1:
            print()
            print("  La salida es subsónica en el eje: el choque entró a la tobera y no hay")
            print("  ondas en el labio. Es el régimen del Tutorial 1.2.")
            return
    print()
    print("  %-36s %9s %9s %8s" % ("", "OpenFOAM", "teoría", "dif."))
    if pb > p1:
        t = choque_oblicuo(M1, pb / p1)
        if t is None:
            raise SystemExit("La presión sube demasiado para un choque adherido al labio")
        b, th, M2 = math.degrees(t[0]), math.degrees(t[1]), t[2]
        pos = choque(lineas)
        fin = fin_del_ajuste(xs, pos)
        m, rms = ajuste(xs, pos, XE + 0.1, fin)
        renglon("β del choque, con el flujo que llega", -math.degrees(math.atan(m)) + ang1, b)
        if uniforme:
            ga, ma, pa = detras(lineas, pos, 0.08, fin)
            renglon("ángulo del flujo detrás, con el eje", ga, ang1 - th)
            renglon("Mach detrás del choque", ma, M2, False)
            renglon("presión detrás del choque", pa, pb, False)
        print("  (ajuste de x = %.2f a %.2f, desviación %.3f m)" % (XE + 0.1, fin, rms))
    else:
        M2, dn, mu1, mu2 = abanico(M1, pb / p1)
        dn, mu1, mu2 = math.degrees(dn), math.degrees(mu1), math.degrees(mu2)
        cabeza, cola = abanico_medido(lineas, pb)
        mc, rc = ajuste(xs, cabeza, XE + 0.15, XE + 0.8)
        renglon("cabeza del abanico, con el eje", -math.degrees(math.atan(mc)), mu1 - ang1)
        if uniforme:
            mt, rt = ajuste(xs, cola, XE + 0.15, XE + 1.0)
            renglon("cola del abanico, con el eje", -math.degrees(math.atan(mt)), mu2 - (ang1 + dn))
            ga, ma, pa = detras(lineas, cola, 0.05)
            renglon("ángulo del flujo detrás, con el eje", ga, ang1 + dn)
            renglon("Mach detrás del abanico", ma, M2, False)
            renglon("presión detrás del abanico", pa, pb, False)
            print("  (desviación de los ajustes: cabeza %.3f m, cola %.3f m)" % (rc, rt))
        else:
            print("  (desviación del ajuste %.3f m)" % rc)
    if not uniforme:
        print("  (la tobera sólo compara lo que nace en el labio: lo demás viene de una")
        print("   salida no uniforme, que la teoría de un solo estado no describe)")
    xd = disco()
    print()
    if xd is None:
        print("  Hasta x = 8 el Mach medio del eje no baja de 1: reflexión regular.")
    else:
        print("  El Mach medio del eje baja de 1 en x = %.2f: disco de Mach." % xd)


if __name__ == "__main__":
    principal()
