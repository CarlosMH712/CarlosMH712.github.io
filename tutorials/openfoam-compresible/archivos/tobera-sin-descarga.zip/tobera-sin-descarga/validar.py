#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compara la corrida de esta carpeta con la teoría cuasi-unidimensional (Tutorial 1.2 de OpenFOAM · Flujo compresible).

    python3 validar.py

Lee la razón de áreas y la presión de descarga de `parametros` (lo escribe el Allrun) y los muestreos del último tiempo
en postProcessing/ejeMedio y postProcessing/secciones. Sólo usa la biblioteca estándar de Python: corre tal cual en la
terminal de blueCFD-Core.

El gas es el normalizado de la rampa (Tutorial 1.1): p0 = 1, T0 = 1 y velocidad del sonido de remanso a0 = 1, con
γ = 1.4; en la media tobera plana el área es proporcional a la semialtura.
"""
import glob
import math
import os

G = 1.4
R = 1 / G                        # a0² = γ R T0 = 1
HE, LC, LD, ESPESOR = 1.0, 2.0, 4.0, 0.1
XS = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 5.99]     # las secciones de system/secciones


# ------------------------------------------------------------------------------------------------ la teoría
def biseccion(f, a, b, tol=1e-12):
    fa = f(a)
    for _ in range(200):
        m = 0.5 * (a + b)
        fm = f(m)
        if (fm > 0) == (fa > 0):
            a, fa = m, fm
        else:
            b = m
        if b - a < tol:
            break
    return 0.5 * (a + b)


def a_sobre_aest(M):
    """Relación área-Mach, A/A*."""
    return (1 / M) * ((2 / (G + 1)) * (1 + 0.5 * (G - 1) * M * M)) ** ((G + 1) / (2 * (G - 1)))


def mach(A, supersonico):
    """Mach de la relación de áreas A/A*, en la rama supersónica o en la subsónica."""
    if A <= 1 + 1e-12:
        return 1.0
    a, b = (1.0, 50.0) if supersonico else (1e-6, 1.0)
    return biseccion(lambda M: a_sobre_aest(M) - A, a, b)


def p_p0(M):
    return (1 + 0.5 * (G - 1) * M * M) ** (-G / (G - 1))


def choque(M1):
    """Mach detrás de un choque normal y la razón de presiones totales p02/p01."""
    M2 = math.sqrt((1 + 0.5 * (G - 1) * M1 ** 2) / (G * M1 ** 2 - 0.5 * (G - 1)))
    r = (((G + 1) * M1 ** 2) / ((G - 1) * M1 ** 2 + 2)) ** (G / (G - 1)) * \
        ((G + 1) / (2 * G * M1 ** 2 - (G - 1))) ** (1 / (G - 1))
    return M2, r


class Tobera:
    """La tobera cosenoidal de tobera.geo con razón de áreas AR."""

    def __init__(self, ar):
        self.ar = ar
        self.ht = HE / ar
        self.p_I = p_p0(mach(ar, False))         # garganta sónica, subsónico hasta la salida
        self.p_II = self.pb_choque(ar)[0]        # choque normal justo en la salida
        self.p_III = p_p0(mach(ar, True))        # diseño

    def area(self, x):
        """A/At en la posición x."""
        s = (LC - x) / LC if x <= LC else (x - LC) / LD
        return (self.ht + (HE - self.ht) * 0.5 * (1 - math.cos(math.pi * s))) / self.ht

    def x_de_area(self, A):
        return biseccion(lambda x: self.area(x) - A, LC, LC + LD)

    def pb_choque(self, A_s):
        """Presión de descarga que pone el choque normal en A/At = A_s, y su p02/p01."""
        _, r = choque(mach(A_s, True))
        return r * p_p0(mach(self.ar * r, False)), r

    def regimen(self, pb):
        if pb > self.p_I:
            return "subsónico"
        if pb > self.p_II:
            return "choque"
        return "diseño"

    def mach_en(self, x, pb, p0_salida=1.0):
        """Mach de la cuasi-1D en x. En el subsónico, A* sale de la presión de salida y de la p0 con que llega."""
        reg = self.regimen(pb)
        if reg == "subsónico":
            Me = math.sqrt(2 / (G - 1) * ((pb / p0_salida) ** (-(G - 1) / G) - 1))
            return mach(self.area(x) * a_sobre_aest(Me) / self.ar, False)
        if reg == "choque":
            A_s = biseccion(lambda A: self.pb_choque(A)[0] - pb, 1 + 1e-9, self.ar)
            if x > self.x_de_area(A_s):
                return mach(self.area(x) * self.pb_choque(A_s)[1], False)
        return mach(self.area(x), x > LC)

    def gasto_bloqueado(self):
        """Gasto de la media tobera con la garganta sónica (p0 = T0 = 1)."""
        return self.ht * ESPESOR * math.sqrt(G / R) * (2 / (G + 1)) ** ((G + 1) / (2 * (G - 1)))


# ------------------------------------------------------------------------------------------------ la corrida
def leer(patron):
    """Las columnas del archivo del último tiempo que coincide con el patrón."""
    rutas = glob.glob(patron)
    if not rutas:
        raise SystemExit("No hay %s: ¿terminó el Allrun?" % patron)
    ruta = max(rutas, key=lambda r: float(os.path.basename(os.path.dirname(r))))
    filas = [[float(v) for v in l.split()] for l in open(ruta) if l.strip() and not l.startswith("#")]
    return [list(c) for c in zip(*filas)]


def trapecio(f, x):
    return sum(0.5 * (f[i] + f[i + 1]) * (x[i + 1] - x[i]) for i in range(len(x) - 1))


def seccion(k):
    """Mach medio (ponderado con el gasto), gasto y presión total media de la sección k."""
    y, p, T, ux, uy = leer("postProcessing/secciones/*/s%02d.xy" % k)[:5]
    M = [math.hypot(a, b) / math.sqrt(G * R * t) for a, b, t in zip(ux, uy, T)]
    w = [pi / (R * t) * a for pi, t, a in zip(p, T, ux)]                              # ρ Ux
    p0 = [pi * (1 + 0.5 * (G - 1) * m * m) ** (G / (G - 1)) for pi, m in zip(p, M)]
    mw = trapecio(w, y)
    return (trapecio([m * a for m, a in zip(M, w)], y) / mw, mw * ESPESOR,
            trapecio([q * a for q, a in zip(p0, w)], y) / mw)


def renglon(nombre, of, teoria, unidad=""):
    dif = 100 * (of / teoria - 1)
    print("  %-38s %9.4f %9.4f %+8.2f %%%s" % (nombre, of, teoria, dif, unidad))


def principal():
    if not os.path.exists("parametros"):
        raise SystemExit("No hay archivo parametros: corra primero ./Allrun AR PB SOLUCIONADOR")
    d = open("parametros").read().split()
    ar, pb = float(d[1]), float(d[3])
    t = Tobera(ar)
    reg = t.regimen(pb)
    secs = [seccion(k) for k in range(len(XS))]
    gasto = secs[0][1] / t.gasto_bloqueado()          # en x = 0.5, lejos de la garganta y de la salida

    print("Tobera AR = %g, pb/p0 = %g: régimen %s" % (ar, pb, reg))
    print("  cuasi-1D: p_I = %.5f, p_II = %.5f, p_III = %.5f" % (t.p_I, t.p_II, t.p_III))
    print()
    print("  %-38s %9s %9s %9s" % ("", "OpenFOAM", "teoría", "diferencia"))
    if reg == "subsónico":
        p0e = secs[-1][2]
        for p0, rotulo in ((1.0, "con p0 = 1, la del depósito"),
                           (p0e, "con p0 = %.4f, la que llega a la salida" % p0e)):
            print("  teoría %s:" % rotulo)
            Me = math.sqrt(2 / (G - 1) * ((pb / p0) ** (-(G - 1) / G) - 1))
            renglon("Mach en la garganta (x = 2)", secs[3][0], t.mach_en(LC, pb, p0))
            renglon("Mach en la salida (x = 5.99)", secs[-1][0], t.mach_en(XS[-1], pb, p0))
            renglon("gasto entre el bloqueado", gasto, p0 * ar / a_sobre_aest(Me))     # p0 A*/At
    else:
        renglon("Mach en la garganta (x = 2)", secs[3][0], 1.0)
        renglon("gasto entre el bloqueado", gasto, 1.0)
        if reg == "diseño":
            for k, x in enumerate(XS):
                if x > LC:
                    renglon("Mach medio de la sección x = %.2f" % x, secs[k][0], t.mach_en(x, pb))
            renglon("presión total media en la salida", secs[-1][2], 1.0)
        else:
            x, p, T, ux, uy = leer("postProcessing/ejeMedio/*/eje.xy")[:5]
            M = [math.hypot(a, b) / math.sqrt(G * R * tt) for a, b, tt in zip(ux, uy, T)]
            i = min(range(len(M) - 1), key=lambda j: M[j + 1] - M[j])       # la caída más brusca del Mach
            A_s = biseccion(lambda A: t.pb_choque(A)[0] - pb, 1 + 1e-9, ar)
            xs = t.x_de_area(A_s)
            print("  %-38s %9.3f %9.3f %+8.2f %%" % ("posición del choque en el eje (m)", x[i], xs,
                                                      100 * (x[i] - xs) / LD))
            renglon("presión total media en la salida", secs[-1][2], t.pb_choque(A_s)[1])
            print("  (la posición difiere en % del largo del divergente;")
            print("   cuasi-1D: choque en A/At = %.3f, con Mach %.4f antes)" % (A_s, mach(A_s, True)))


if __name__ == "__main__":
    principal()
